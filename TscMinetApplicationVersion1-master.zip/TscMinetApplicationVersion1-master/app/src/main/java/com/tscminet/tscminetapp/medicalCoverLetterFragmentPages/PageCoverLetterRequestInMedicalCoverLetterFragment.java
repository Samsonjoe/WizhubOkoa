package com.tscminet.tscminetapp.medicalCoverLetterFragmentPages;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.tscminet.tscminetapp.R;
import com.tscminet.tscminetapp.loginPage.MySingleton;
import com.tscminet.tscminetapp.loginPage.SessionHandler;
import com.tscminet.tscminetapp.loginPage.User;
import com.tscminet.tscminetapp.utils.HttpsTrustManager;

import org.json.JSONException;
import org.json.JSONObject;


public class PageCoverLetterRequestInMedicalCoverLetterFragment extends Fragment {

    private static final String KEY_STATUS = "status";
    private static final String KEY_MESSAGE = "message";

    private static final String KEY_EMPTY = "";

    private static final String KEY_FULL_NAME = "FullName";
    private static final String KEY_REASON = "Reason";
    private static final String KEY_EMAIL = "Email";

    private static final String KEY_USERNAME = "username";
    private static final String KEY_PHONE = "PhoneNo";

    private static final String  KEY_DEPENDANT_NAME = "DependantName";
    private static final String KEY_DEPENDANT_DATE_OF_BIRTH = "DependantBirthDate" ;
    private static final String KEY_DEPENDANT_GENDER = "Gender";
    private static final String KEY_DEPENDANT_DISABLED = "Disabled";
    private static final String KEY_DEPENDANT_RELATIONSHIP = "DependantRelationship";
    private static final String KEY_DEPENDANT_PHONE = "MobileNumber" ;
    private static final String KEY_DEPENDANT_IDS = "DependantsIds" ;

    private SessionHandler session;
    private ProgressDialog pDialog;

    private String FullName_string;
    private String Reason_string;
    private String Email_string;
    private String DependantsIds_string;
    private String Username_string;
    private String Phone_number_string;

    private EditText etReason_typed;
    private EditText etEmail_typed;

    private TextView tvFullName;
    private TextView tvDateOfBirth;
    private TextView tvGender;
    private TextView tvDisabled;
    private TextView tvRelationship;
    private TextView tvPhone;
    private TextView tvIds;
    private TextView textViewRequestNameInMedicalCover;


    private String request_medical_cover_url = "https://collaborationkenya.minet.com/MinetAPI/tsc/RequestMedicalCover";


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_pagecoverletterrequestinmedicalcoverletterfragment, container, false);

        session = new SessionHandler(getActivity().getApplicationContext());
        User user = session.getUserDependants();

        tvFullName =(TextView) view.findViewById(R.id.TXTview_fullName_medical_cover);
        tvDateOfBirth =(TextView) view.findViewById(R.id.TXTview_dob_medical_cover);
        tvGender =(TextView) view.findViewById(R.id.TXTview_gender_medical_cover);
        tvDisabled =(TextView) view.findViewById(R.id.TXTview_disabled_medical_cover);
        tvRelationship =(TextView) view.findViewById(R.id.TXTview_relationship_medical_cover);
        tvPhone =(TextView) view.findViewById(R.id.TXTview_phone_number_medical_cover);
        tvIds =(TextView) view.findViewById(R.id.TXTview_id_number_medical_cover);
        textViewRequestNameInMedicalCover = (TextView) view.findViewById(R.id.textViewRequestNameInMedicalCover);

        etEmail_typed = (EditText) view.findViewById(R.id.EDITTEXT_EmailAddressCoverRequest);
        etReason_typed = (EditText) view.findViewById(R.id.EDITTEXT_ReasonForRequestCoverRequest);


        String dependantName= getArguments().getString(KEY_DEPENDANT_NAME);
        String dependantDob= getArguments().getString(KEY_DEPENDANT_DATE_OF_BIRTH);
        String dependantGender= getArguments().getString(KEY_DEPENDANT_GENDER);
        String dependantDisabled= getArguments().getString(KEY_DEPENDANT_DISABLED);
        String dependantRelationship= getArguments().getString(KEY_DEPENDANT_RELATIONSHIP);
        String dependantPhone= getArguments().getString(KEY_DEPENDANT_PHONE);
        String dependantIds= getArguments().getString(KEY_DEPENDANT_IDS);

        textViewRequestNameInMedicalCover.setText(dependantName);
        tvFullName.setText(dependantName);
        tvDateOfBirth.setText(dependantDob);
        tvGender.setText(dependantGender);
        tvDisabled.setText(dependantDisabled);
        tvRelationship.setText(dependantRelationship);
        tvPhone.setText(dependantPhone);
        tvIds.setText(dependantIds);


        Button SubmitMedicalCoverRequest = view.findViewById(R.id.btnSubmitMedicalCoverRequest);
        SubmitMedicalCoverRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                User user = session.getUserDetails();

                //Retrieve the data entered in the edit text
                String dependantName= getArguments().getString(KEY_DEPENDANT_NAME);
                String dependantIds= getArguments().getString(KEY_DEPENDANT_IDS);

                FullName_string = dependantName ;
                Email_string = etEmail_typed.getText().toString().trim();
                Reason_string = etReason_typed.getText().toString().trim();
                DependantsIds_string = dependantIds;
                Username_string = user.getUsername();
                Phone_number_string= user.getUserPhoneNumber();
                if (validateInputs()) {
                    request_claim();

                }
            }
        });

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }



    /**
     * Display Progress bar while Logging in
     */

    private void displayLoader() {
        pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage("Sending Request.. Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();

    }

    private void request_claim() {
        displayLoader();
        JSONObject request = new JSONObject();

        //ssl security
        HttpsTrustManager.allowMINETSSL();

        try {

            //Populate the request parameters
            request.put(KEY_FULL_NAME, FullName_string);
            request.put(KEY_REASON, Reason_string);
            request.put(KEY_EMAIL, Email_string);
            request.put(KEY_DEPENDANT_IDS, DependantsIds_string);
            request.put(KEY_USERNAME, Username_string);
            request.put(KEY_PHONE, Phone_number_string);


        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest jsArrayRequestMedical = new JsonObjectRequest
                (Request.Method.POST, request_medical_cover_url, request, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        pDialog.dismiss();
                        try {
                            //Check if user got logged in successfully

                            if (response.getInt(KEY_STATUS) == 0) {

                                Toast.makeText(getActivity().getApplicationContext(),
                                        "Kindly confirm via text sent ", Toast.LENGTH_SHORT).show();

                            }else{
                                Toast.makeText(getActivity().getApplicationContext(),
                                        "Kindly confirm via text sent ", Toast.LENGTH_SHORT).show();

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pDialog.dismiss();

                        //Display error message whenever an error occurs
                        Toast.makeText(getActivity().getApplicationContext(),
                                error.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });


        // Access the RequestQueue through your singleton class.
        MySingleton.getInstance(getActivity()).addToRequestQueue(jsArrayRequestMedical);
    }

    /**
     * Validates inputs and shows error if any
     * @return
     */
    private boolean validateInputs() {

        if(KEY_EMPTY.equals(Email_string)){
            etEmail_typed.setError("Email Address cannot be empty");
            etEmail_typed.requestFocus();
            return false;
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(Email_string).matches()) {
            etEmail_typed.setError("enter a valid email address");
            etEmail_typed.requestFocus();
            return false;
        }
        if (KEY_EMPTY.equals(Reason_string)) {
            etReason_typed.setError("Reason cannot be empty");
            etReason_typed.requestFocus();
            return false;

        }
        return true;
    }


}
