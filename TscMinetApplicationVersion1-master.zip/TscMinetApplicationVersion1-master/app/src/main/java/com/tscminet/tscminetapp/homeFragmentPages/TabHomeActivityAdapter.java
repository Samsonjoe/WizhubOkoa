package com.tscminet.tscminetapp.homeFragmentPages;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

public class TabHomeActivityAdapter extends FragmentStatePagerAdapter {

String[] tabArray = new String[]{"User Profile","Dependants","Uploaded Files"};
Integer tabNumber = 3;


public TabHomeActivityAdapter(FragmentManager fm) {
    //super(fm);
    super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
}

@Nullable
@Override
public CharSequence getPageTitle(int position) {
    return tabArray[position];
}

@Override
public Fragment getItem(int position) {

    switch (position){
        case 0:
            UserProfileInHomeFragment one1 = new UserProfileInHomeFragment();
            return one1;
        case 1:
          //  DependantsInHomeFragment two2 = new DependantsInHomeFragment();
          //  return two2;
        //case 2:
            UploadFilesInHomeFragment three3 = new UploadFilesInHomeFragment();
            return three3;

    }
    return null;
}

@Override
public int getCount() {
    return tabNumber;
}}
