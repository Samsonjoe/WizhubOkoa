package com.tscminet.tscminetapp.fragments;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.tscminet.tscminetapp.R;
import com.tscminet.tscminetapp.loginPage.HttpHandler;
import com.tscminet.tscminetapp.loginPage.MySingleton;
import com.tscminet.tscminetapp.loginPage.SessionHandler;
import com.tscminet.tscminetapp.loginPage.User;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

    public class UnregisteredTeachersFragment extends androidx.fragment.app.Fragment {

        public UnregisteredTeachersFragment(){
            // Required empty public constructor
        }

        private static final String KEY_STATUS = "status";
        private static final String KEY_MESSAGE = "message";

        private static final String KEY_SCHOOL_NAME_UNREGISTERED = "School";
        private static final String KEY_COUNTY_UNREGISTERED = "County";
        private static final String KEY_SPINNER_COUNTY = "County";

        private SessionHandler session;
        List<String> schoolList;
        ArrayList<HashMap<String, String>> unregisteredTeachersList;

        private ListView lv;

        //JSON Node Names
        private static final String KEY_TEACHER_NAME_CHECKED = "TeacherName";
        private static final String KEY_SCHOOL_NAME_CHECKED = "School";
        private static final String KEY_COUNTY_CHECKED = "County";





        private String TAG = UnregisteredTeachersFragment.class.getSimpleName();

        private static final String KEY_SCHOOL_NAME = "School";

        private  Spinner spinnerSchoolNames, spinnerCounty;
        private String school_name;
        private String county_name;

        private Button ButtonCheckUnregisteredTeachers;
        private ProgressDialog pDialog;


        @Nullable
        @Override
        public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            final View view = inflater.inflate(R.layout.fragment_unregistered_teachers, container, false);
            session = new SessionHandler(getActivity().getApplicationContext());

            schoolList = new ArrayList<String>();
            spinnerSchoolNames = (Spinner) view.findViewById(R.id.spinnerSchoolUnregisteredTeachers);
            spinnerCounty = (Spinner) view.findViewById(R.id.spinnerCountyUnregisteredTeachers);
            new GetAllSchools().execute();

            ButtonCheckUnregisteredTeachers = view.findViewById(R.id.ButtonCheckUnregisteredTeachers);
            ButtonCheckUnregisteredTeachers.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    //Retrieve the data entered in the spinner
                    school_name = spinnerSchoolNames.getSelectedItem().toString().trim();
                    county_name = spinnerCounty.getSelectedItem().toString().trim();

                    if (validateInputs()) {

                        new Get_unregistered_teachers().execute();
                    }
                }
            });


            unregisteredTeachersList = new ArrayList<>();
            lv = (ListView) view.findViewById(R.id.records_view_unregistered_teachers);

            return view;
        }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    /**
     * Display Progress bar while Logging in
     */

    private void displayLoader() {
        pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage("submiting details.. Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();

    }


    private class GetAllSchools extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... arg0) {

            User user = session.getUserAllSchools();
            String name =user.getUserAllSchools();
            String jsonStr = name;

            Log.e(TAG, "Response from url: " + jsonStr);
            if(schoolList.isEmpty()) {
                if (jsonStr != null) {
                    try {
                        JSONObject jsonObj = new JSONObject(jsonStr);

                        // Getting JSON Array node
                        JSONArray schools = jsonObj.getJSONArray("Schools");

                        // looping through All Contacts
                        for (int i = 0; i < schools.length(); i++) {

                            JSONObject c = schools.getJSONObject(i);

                            // String policy_id = c.getString("");
                            String school_name = c.getString(KEY_SCHOOL_NAME);

                            schoolList.add(school_name);


                        }
                    } catch (final JSONException e) {
                        Log.e(TAG, "Json parsing error: " + e.getMessage());
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getActivity().getApplicationContext(),
                                        "Json parsing error: " + e.getMessage(),
                                        Toast.LENGTH_LONG).show();
                            }
                        });

                    }

                } else {
                    Log.e(TAG, "Couldn't get json from server.");
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getActivity().getApplicationContext(),
                                    "Couldn't get json from server. Check LogCat for possible errors!",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            if (getActivity() != null) {
                // Code goes here.
                ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>
                        (getActivity(), android.R.layout.simple_spinner_item,schoolList);

                dataAdapter.setDropDownViewResource
                        (android.R.layout.simple_spinner_dropdown_item);

                spinnerSchoolNames.setAdapter(dataAdapter);
                spinnerSchoolNames.setSelection(1);

            }
        }
    }



    private class Get_unregistered_teachers extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected Void doInBackground(Void... arg0) {

            try {
                String query = URLEncoder.encode(school_name, "utf-8");
                HttpHandler sh = new HttpHandler();
                String teachersNotRegistered_url = "https://collaborationkenya.minet.com/MinetAPI/tsc/teachersnotregistered?SchoolName="+query+"&County="+county_name;

                // Making a request to url and getting response
                String jsonStr = sh.makeServiceCall(teachersNotRegistered_url);

                Log.e(TAG, "Response from url: " + jsonStr);

                if(unregisteredTeachersList.isEmpty()) {
                    if (jsonStr != null) {
                        try {
                            JSONObject jsonObj = new JSONObject(jsonStr);

                            // Getting JSON Array node
                            JSONArray dependants = jsonObj.getJSONArray("TeachersList");

                            // looping through All Contacts
                            for (int i = 0; i < dependants.length(); i++) {

                                JSONObject c = dependants.getJSONObject(i);

                                // String policy_id = c.getString("");
                                String teacher_name_checked = c.getString(KEY_TEACHER_NAME_CHECKED);
                                String school_name_checked = c.getString(KEY_SCHOOL_NAME_CHECKED);
                                String county_checked = c.getString(KEY_COUNTY_CHECKED);



                                // tmp hash map for single dependant
                                HashMap<String, String> dependant = new HashMap<>();

                                // adding each child node to HashMap key => value
                                dependant.put(KEY_TEACHER_NAME_CHECKED, teacher_name_checked);
                                dependant.put(KEY_SCHOOL_NAME_CHECKED, school_name_checked);
                                dependant.put(KEY_COUNTY_CHECKED, county_checked);


                                unregisteredTeachersList.add(dependant);

                            }
                        } catch (final JSONException e) {
                            Log.e(TAG, "Json parsing error: " + e.getMessage());
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getActivity().getApplicationContext(),
                                            "Json parsing error: " + e.getMessage(),
                                            Toast.LENGTH_LONG).show();
                                }
                            });

                        }

                    } else {
                        Log.e(TAG, "Couldn't get json from server.");
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getActivity().getApplicationContext(),
                                        "Couldn't get json from server. Check LogCat for possible errors!",
                                        Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                }
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            if (getActivity() != null) {
                // Code goes here.
                ListAdapter adapter = new SimpleAdapter(getActivity(), unregisteredTeachersList, R.layout.list_item_unregistered_teachers_in_unregistred_teacher_fragment, new String[]{KEY_TEACHER_NAME_CHECKED, KEY_SCHOOL_NAME_CHECKED, KEY_COUNTY_CHECKED},
                        new int[]{ R.id.full_name_UNREGISTERED_TEACHER,
                                R.id.school_name_UNREGISTERED_TEACHER,R.id.county_UNREGISTERED_TEACHER});


                lv.setAdapter(adapter);


            }

            ListUtils.setDynamicHeight(lv);
           // spinner.setVisibility(View.GONE);



        }
    }

    public static class ListUtils {
        public static void setDynamicHeight(ListView mListView) {
            ListAdapter mListAdapter = mListView.getAdapter();
            if (mListAdapter == null) {
                // when adapter is null
                return;
            }
            int height = 0;
            int desiredWidth = View.MeasureSpec.makeMeasureSpec(mListView.getWidth(), View.MeasureSpec.UNSPECIFIED);
            for (int i = 0; i < mListAdapter.getCount(); i++) {
                View listItem = mListAdapter.getView(i, null, mListView);
                listItem.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
                height += listItem.getMeasuredHeight();
            }
            ViewGroup.LayoutParams params = mListView.getLayoutParams();
            params.height = height + (mListView.getDividerHeight() * (mListAdapter.getCount() - 1));
            mListView.setLayoutParams(params);
            mListView.requestLayout();
        }
    }

    /**
     * Validates inputs and shows error if any
     * @return
     */
    private boolean validateInputs() {

        if (KEY_SPINNER_COUNTY.equals(county_name)) {
            Toast.makeText(getActivity(), "Kindly Select a county", Toast.LENGTH_SHORT).show();
            spinnerCounty.requestFocus();
            return false;
        }

        return true;
    }

}

   /* private void Chronic_enrolment() {
    displayLoader();
    JSONObject request = new JSONObject();
    try {

        //Populate the request parameters
        request.put(KEY_SCHOOL_NAME_UNREGISTERED, school_name);
        request.put(KEY_COUNTY_UNREGISTERED, county_name);



    } catch (JSONException e) {
        e.printStackTrace();
    }
    JsonObjectRequest jsArrayRequest = new JsonObjectRequest
            (Request.Method.POST, teachersNotRegistered_url, request, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    pDialog.dismiss();
                    try {
                        //Check if user got logged in successfully

                        if (response.getInt(KEY_STATUS) == 0) {

                            Toast.makeText(getActivity().getApplicationContext(),
                                    "Search successfully", Toast.LENGTH_SHORT).show();


                        }else{
                            Toast.makeText(getActivity().getApplicationContext(),
                                    response.getString(KEY_MESSAGE), Toast.LENGTH_SHORT).show();

                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    pDialog.dismiss();

                    //Display error message whenever an error occurs
                    Toast.makeText(getActivity().getApplicationContext(),
                            error.getMessage(), Toast.LENGTH_SHORT).show();

                }
            });


    // Access the RequestQueue through your singleton class.
    MySingleton.getInstance(getActivity()).addToRequestQueue(jsArrayRequest);
}
*/
