package com.tscminet.tscminetapp.loginPage;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.tscminet.tscminetapp.navDrawerMain.TscAccountActivity;
import com.tscminet.tscminetapp.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;


public class VerificationCodeActivity extends AppCompatActivity {


    private String TAG = VerificationCodeActivity.class.getSimpleName();
    ArrayList<HashMap<String, String>> policyList;
    private static final String KEY_STATUS = "status";
    private static final String KEY_MESSAGE = "message";

    private static final String KEY_EMPTY = "";


    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";

    private static final String KEY_FIRST_NAME = "Fname";
    private static final String KEY_SECOND_NAME = "Sname";
    private static final String KEY_LAST_NAME = "Lname";


    private static final String KEY_FULL_NAME = "full_name";
    private static final String KEY_JOB_GROUP = "job_group";
    private static final String KEY_PHONE_NUMBER= "cellphone";
    private static final String KEY_ID_NUMBER = "id_number";
    private static final String KEY_KRA_PIN = "kra_pin";
    private static final String KEY_DATE_OF_BIRTH= "date_of_birth";
    private static final String KEY_GENDER = "gender";
    private static final String KEY_COUNTY = "county";
    private static final String KEY_ROLE = "role";
    private static final String KEY_NHIF_NUMBER = "nhif_number";
    private EditText etPassword;
    private String username;
    private String password;

    private String login_url = "https://collaborationkenya.minet.com/MinetAPI/tsc/OTPVerification";
    private SessionHandler session;
    private ProgressDialog pDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        session = new SessionHandler(getApplicationContext());

        setContentView(R.layout.activity_verification_code);

        etPassword = findViewById(R.id.etLoginVerificationCode);

        Button SubmitVerification = findViewById(R.id.ButtonSubmitVerificationCode);
        SubmitVerification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Retrieve the data entered in the edit texts
                String UsernameFromMain = (String) getIntent().getStringExtra("USERNAME_TO_VERIFICATION_PAGE");
                username = UsernameFromMain;
                password = etPassword.getText().toString().trim();
                if (validateInputs()) {
                    login();

                }

            }
        });
    }




    /**
     * Launch Dashboard Activity on Successful Login
     */
    private void loadDashboard() {
        Intent i = new Intent(getApplicationContext(), TscAccountActivity.class);
        startActivity(i);
        finish();
        new GetDependants().execute();
        new GetUploadedFiles().execute();
        new GetAllSchool().execute();

    }

    /**
     * Display Progress bar while Logging in
     */

    private void displayLoader() {
        pDialog = new ProgressDialog(VerificationCodeActivity.this);
        pDialog.setMessage("Logging In.. Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();

    }

    private void login() {
        displayLoader();
        JSONObject request = new JSONObject();
        try {
            //Populate the request parameters
            request.put(KEY_USERNAME, username);
            request.put(KEY_PASSWORD, password);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest jsArrayRequest = new JsonObjectRequest
                (Request.Method.POST, login_url, request, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        pDialog.dismiss();
                        try {
                            //Check if user got logged in successfully

                            if (response.getInt(KEY_STATUS) == 0) {

                                //response.getString(KEY_FIRST_NAME),response.getString(KEY_SECOND_NAME),response.getString(KEY_LAST_NAME),

                                session.loginUser(username,response.getString(KEY_FULL_NAME),response.getString(KEY_JOB_GROUP),response.getString(KEY_ID_NUMBER),
                                        response.getString(KEY_PHONE_NUMBER),response.getString(KEY_KRA_PIN),response.getString(KEY_DATE_OF_BIRTH),
                                        response.getString(KEY_GENDER),response.getString(KEY_COUNTY),response.getString(KEY_ROLE),response.getString(KEY_NHIF_NUMBER));

                                Toast.makeText(getApplicationContext(),
                                        "Successful", Toast.LENGTH_SHORT).show();
                                loadDashboard();

                            }else{
                                Toast.makeText(getApplicationContext(),
                                        response.getString(KEY_MESSAGE), Toast.LENGTH_SHORT).show();

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pDialog.dismiss();

                        //Display error message whenever an error occurs
                        Toast.makeText(getApplicationContext(),
                                error.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });


        // Access the RequestQueue through your singleton class.
        MySingleton.getInstance(this).addToRequestQueue(jsArrayRequest);
    }

    /**
     * Validates inputs and shows error if any
     * @return
     */
    private boolean validateInputs() {

        if(KEY_EMPTY.equals(password)){
            etPassword.setError("Verification cannot be empty");
            etPassword.requestFocus();
            return false;
        }
        return true;
    }



    private class GetDependants extends AsyncTask<Void, Void, Void> {


        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();
            // Making a request to url and getting response
            String UsernameFromMain = (String) getIntent().getStringExtra("USERNAME_TO_VERIFICATION_PAGE");
            String url = "https://collaborationkenya.minet.com/MinetAPI/tsc/Dependants?username="+UsernameFromMain;
            String jsonStr = sh.makeServiceCall(url);

            Log.e(TAG, "Response from url: " + jsonStr);

                    try {
                        JSONObject jsonObjAllDependants = new JSONObject(jsonStr);
                        String yourStringDependants =  jsonObjAllDependants.toString();
                        session.loginSaveUserDependants(yourStringDependants);


                    } catch (final JSONException e) {
                        Log.e(TAG, "Json parsing error: " + e.getMessage());
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(),
                                        "Json parsing error: " + e.getMessage(),
                                        Toast.LENGTH_LONG).show();
                            }
                        });

                    }

            return null;
        }

    }

    private class GetUploadedFiles extends AsyncTask<Void, Void, Void> {


        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();
            // Making a request to url and getting response
            String UsernameFromMain = (String) getIntent().getStringExtra("USERNAME_TO_VERIFICATION_PAGE");
            String url = "https://collaborationkenya.minet.com/MinetAPI/tsc/All_files?username="+UsernameFromMain;
            String jsonStr = sh.makeServiceCall(url);

            Log.e(TAG, "Response from url: " + jsonStr);


            try {
                JSONObject jsonObjAllUploads = new JSONObject(jsonStr);
                String yourStringUploads =  jsonObjAllUploads.toString();
                session.loginSaveUserUploads(yourStringUploads);


            } catch (final JSONException e) {
                Log.e(TAG, "Json parsing error: " + e.getMessage());
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Json parsing error: " + e.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });

            }

            return null;
        }

    }

    private class GetAllSchool extends AsyncTask<Void, Void, Void> {


        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();
            // Making a request to url and getting response
            String url = "https://collaborationkenya.minet.com/MinetAPI/tsc/Allschools";
            String jsonStr = sh.makeServiceCall(url);

            Log.e(TAG, "Response from url: " + jsonStr);


            try {
                JSONObject jsonObj = new JSONObject(jsonStr);
                String allSchools =  jsonObj.toString();
                session.loginSaveUserAllSchools(allSchools);


            } catch (final JSONException e) {
                Log.e(TAG, "Json parsing error: " + e.getMessage());
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Json parsing error: " + e.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });

            }

            return null;
        }

    }



}
