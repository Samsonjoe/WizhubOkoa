package com.tscminet.tscminetapp.retrofit_networkRelatedClass;

import androidx.annotation.NonNull;

import com.google.gson.Gson;
import com.orhanobut.logger.AndroidLogAdapter;
import com.orhanobut.logger.Logger;
import com.tscminet.tscminetapp.retrofit_modelClass.EventModel;
import com.tscminet.tscminetapp.retrofit_modelClass.ImageSenderInfo;
import com.tscminet.tscminetapp.retrofit_modelClass.ResponseModel;


import org.greenrobot.eventbus.EventBus;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class NetworkCall {

    //Spouse upload files
    public static void fileUpload(String filePath,String filePath2, ImageSenderInfo imageSenderInfo) {


        ApiInterface apiInterface = RetrofitApiClient.getClient().create(ApiInterface.class);
        Logger.addLogAdapter(new AndroidLogAdapter());

        File file = new File(filePath);
        File file2 = new File(filePath2);
        //create RequestBody instance from file
        RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file); //allow image and any other file
        RequestBody requestFile2 = RequestBody.create(MediaType.parse("multipart/form-data"), file2); //allow image and any other file


        // MultipartBody.Part is used to send also the actual file name
        MultipartBody.Part body = MultipartBody.Part.createFormData("nationalID", file.getName(), requestFile);
        MultipartBody.Part body2 = MultipartBody.Part.createFormData("marriageCertificate", file2.getName(), requestFile2);

        Gson gson = new Gson();
        String patientData = gson.toJson(imageSenderInfo);

        RequestBody description = RequestBody.create(MultipartBody.FORM, patientData);

        // finally, execute the request
        Call<ResponseModel> call = apiInterface.fileUpload(description, body , body2);
        call.enqueue(new Callback<ResponseModel>() {
            @Override
            public void onResponse(@NonNull Call<ResponseModel> call, @NonNull Response<ResponseModel> response) {
                Logger.d("Response: " + response);

                ResponseModel responseModel = response.body();

                if(responseModel != null){
                    EventBus.getDefault().post(new EventModel("response", responseModel.getMessage()));
                    Logger.d("Response code " + response.code() +
                            " Response Message: " + responseModel.getMessage());
                } else
                    EventBus.getDefault().post(new EventModel("response", "ResponseModel is NULL"));
            }

            @Override
            public void onFailure(@NonNull Call<ResponseModel> call, @NonNull Throwable t) {
                Logger.d("Exception: " + t);
                EventBus.getDefault().post(new EventModel("response", t.getMessage()));
            }
        });
    }


    //Daughter or son with disability
    public static void fileUploadDisability(String filePath,String filePath2, String filePath3, String filePath4, ImageSenderInfo imageSenderInfo) {


        ApiInterface apiInterface = RetrofitApiClient.getClient().create(ApiInterface.class);
        Logger.addLogAdapter(new AndroidLogAdapter());

        File file = new File(filePath);
        File file2 = new File(filePath2);
        File file3 = new File(filePath3);
        File file4 = new File(filePath4);
        //create RequestBody instance from file
        RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file); //allow image and any other file
        RequestBody requestFile2 = RequestBody.create(MediaType.parse("multipart/form-data"), file2); //allow image and any other file
        RequestBody requestFile3 = RequestBody.create(MediaType.parse("multipart/form-data"), file3); //allow image and any other file
        RequestBody requestFile4 = RequestBody.create(MediaType.parse("multipart/form-data"), file4); //allow image and any other file

        // MultipartBody.Part is used to send also the actual file name
        MultipartBody.Part body = MultipartBody.Part.createFormData("birthCertificate", file.getName(), requestFile);
        MultipartBody.Part body2 = MultipartBody.Part.createFormData("nationalID", file2.getName(), requestFile2);
        MultipartBody.Part body3 = MultipartBody.Part.createFormData("proofDisability", file3.getName(), requestFile3);
        MultipartBody.Part body4 = MultipartBody.Part.createFormData("proofSchool", file4.getName(), requestFile4);

        Gson gson = new Gson();
        String patientData = gson.toJson(imageSenderInfo);

        RequestBody description = RequestBody.create(MultipartBody.FORM, patientData);

        // finally, execute the request
        Call<ResponseModel> call = apiInterface.fileUpload2(description, body , body2,body3,body4);
        call.enqueue(new Callback<ResponseModel>() {
            @Override
            public void onResponse(@NonNull Call<ResponseModel> call, @NonNull Response<ResponseModel> response) {
                Logger.d("Response: " + response);

                ResponseModel responseModel = response.body();

                if(responseModel != null){
                    EventBus.getDefault().post(new EventModel("response", responseModel.getMessage()));
                    Logger.d("Response code " + response.code() +
                            " Response Message: " + responseModel.getMessage());
                } else
                    EventBus.getDefault().post(new EventModel("response", "ResponseModel is NULL"));
            }

            @Override
            public void onFailure(@NonNull Call<ResponseModel> call, @NonNull Throwable t) {
                Logger.d("Exception: " + t);
                EventBus.getDefault().post(new EventModel("response", t.getMessage()));
            }
        });
    }

 // son daughter with no disability
    public static void fileUploadNOdisability(String filePath,String filePath2, String filePath3, ImageSenderInfo imageSenderInfo) {


        ApiInterface apiInterface = RetrofitApiClient.getClient().create(ApiInterface.class);
        Logger.addLogAdapter(new AndroidLogAdapter());

        File file = new File(filePath);
        File file2 = new File(filePath2);
        File file3 = new File(filePath3);

        //create RequestBody instance from file
        RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file); //allow image and any other file
        RequestBody requestFile2 = RequestBody.create(MediaType.parse("multipart/form-data"), file2); //allow image and any other file
        RequestBody requestFile3 = RequestBody.create(MediaType.parse("multipart/form-data"), file3); //allow image and any other file


        // MultipartBody.Part is used to send also the actual file name
        MultipartBody.Part body = MultipartBody.Part.createFormData("birthCertificate", file.getName(), requestFile);
        MultipartBody.Part body2 = MultipartBody.Part.createFormData("nationalID", file2.getName(), requestFile2);
        MultipartBody.Part body3 = MultipartBody.Part.createFormData("proofSchool", file3.getName(), requestFile3);

        Gson gson = new Gson();
        String patientData = gson.toJson(imageSenderInfo);

        RequestBody description = RequestBody.create(MultipartBody.FORM, patientData);

        // finally, execute the request
        Call<ResponseModel> call = apiInterface.fileUpload3(description, body , body2, body3);
        call.enqueue(new Callback<ResponseModel>() {
            @Override
            public void onResponse(@NonNull Call<ResponseModel> call, @NonNull Response<ResponseModel> response) {
                Logger.d("Response: " + response);

                ResponseModel responseModel = response.body();

                if(responseModel != null){
                    EventBus.getDefault().post(new EventModel("response", responseModel.getMessage()));
                    Logger.d("Response code " + response.code() +
                            " Response Message: " + responseModel.getMessage());
                } else
                    EventBus.getDefault().post(new EventModel("response", "ResponseModel is NULL"));
            }

            @Override
            public void onFailure(@NonNull Call<ResponseModel> call, @NonNull Throwable t) {
                Logger.d("Exception: " + t);
                EventBus.getDefault().post(new EventModel("response", t.getMessage()));
            }
        });
    }

}