package com.tscminet.tscminetapp.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.tscminet.tscminetapp.R;
import com.tscminet.tscminetapp.loginPage.JavaMailAPI;
import com.tscminet.tscminetapp.loginPage.SessionHandler;
import com.tscminet.tscminetapp.loginPage.User;

public class FeedbackFragment extends androidx.fragment.app.Fragment {

    public FeedbackFragment(){
        // Required empty public constructor
    }

    private SessionHandler session;

    private static final String KEY_EMPTY = "";
    private String subjectstring;
    private String feedbackstring;

    EditText editTextSubjectFeedback,editTextFeedback;
    Button mFeedbackSendEmail;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_feedback, container, false);
        session = new SessionHandler(getActivity().getApplicationContext());

        editTextSubjectFeedback = view.findViewById(R.id.editTextSubjectFeedback);
        editTextFeedback = view.findViewById(R.id.editTextFeedback);
        mFeedbackSendEmail=(Button)view.findViewById(R.id.btnSubmitFeedback);
        mFeedbackSendEmail.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                subjectstring =editTextSubjectFeedback.getText().toString().toLowerCase().trim();
                feedbackstring = editTextFeedback.getText().toString().trim();
                if (validateInputs()) {
                    sendMail();
                    //Clear EditText
                    editTextSubjectFeedback.getText().clear();
                    editTextFeedback.getText().clear();
                }
            }
        });


        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    private void sendMail() {

        // String mail = emailSignup.getText().toString().trim();
        User user = session.getUserDetails();
        String mail = "mmc.membership@minet.co.ke";
        String Subject =editTextSubjectFeedback.getText().toString().trim();
        String SubjectMain= "FEEDBACK: "+Subject;
        String FeedBackFromUser =editTextFeedback.getText().toString().trim();
        String Feedback =FeedBackFromUser+"\n\nPhone Number of user: "+user.getUsername()+"\n\nRegards,\n"+user.getFullName();


        //send Mail
        JavaMailAPI javaMailAPI = new JavaMailAPI(getActivity(),mail,SubjectMain,Feedback);
        javaMailAPI.execute();
    }

    /**
     * Validates inputs and shows error if any
     * @return
     */
    private boolean validateInputs() {
        if(KEY_EMPTY.equals(subjectstring)){
            editTextSubjectFeedback.setError("Subject cannot be empty");
            editTextSubjectFeedback.requestFocus();
            return false;
        }
        if(KEY_EMPTY.equals(feedbackstring)){
            editTextFeedback.setError("Feedback cannot be empty");
            editTextFeedback.requestFocus();
            return false;
        }
        return true;
    }
}
