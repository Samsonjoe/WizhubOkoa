package com.tscminet.tscminetapp.homeFragmentPages;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.tscminet.tscminetapp.R;
import com.tscminet.tscminetapp.loginPage.MySingleton;
import com.tscminet.tscminetapp.loginPage.SessionHandler;
import com.tscminet.tscminetapp.loginPage.User;
import com.tscminet.tscminetapp.utils.HttpsTrustManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Objects;

import static org.greenrobot.eventbus.util.ErrorDialogManager.KEY_MESSAGE;

public class EditProfileInUserProfileInHomeFragment extends Fragment {

    private TextView tvEditProfileFullName;
    private TextView tvEditProfileDOB;
    private TextView tvEditProfileRole;
    private TextView tvEditProfileStationName;
    private TextView tvEditProfileJobGroup;
    private TextView tvEditProfileCounty;

    private EditText etEditProfilePhone;
    private EditText etEditProfileNHIF;
    private EditText etEditProfileKra;
    private EditText editTextListOfItemsChangedEditPeofile;

    private Spinner spinnerEditProfileGender;

    private String stringUsername;
    private String stringPhone;
    private String stringNhif;
    private String stringKra;
    private String stringGender;
    private String stringItemsChanged;


    private static final String KEY_USERNAME ="tsc_no";
    private static final String KEY_PHONE_NUMBER= "cellphone";
    private static final String KEY_KRA_PIN = "kra_pin";
    private static final String KEY_GENDER = "gender";
    private static final String KEY_NHIF_NUMBER = "nhif_number";
    private static final String KEY_ITEMS_CHANGED = "items_changed";


    private SessionHandler session;
    private static final String KEY_EMPTY = "";
    private static final String KEY_STATUS = "status";


    private ProgressDialog pDialog;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        session = new SessionHandler(Objects.requireNonNull(getActivity()).getApplicationContext());
        User user = session.getUserDetails();
        
        View view = inflater.inflate(R.layout.fragment_edit_profile_in_user_profile_in_home_fragment,container,false);

        tvEditProfileFullName = view.findViewById(R.id.tvEditProfileFullName);
        tvEditProfileDOB = view.findViewById(R.id.tvEditProfileDOB);
        tvEditProfileRole = view.findViewById(R.id.tvEditProfileRole);
        tvEditProfileStationName = view.findViewById(R.id.tvEditProfileStationName);
        tvEditProfileJobGroup = view.findViewById(R.id.tvEditProfileJobGroup);
        tvEditProfileCounty = view.findViewById(R.id.tvEditProfileCounty);

        etEditProfilePhone = view.findViewById(R.id.etEditProfilePhone);
        etEditProfileNHIF = view.findViewById(R.id.etEditProfileNHIF);
        etEditProfileKra = view.findViewById(R.id.etEditProfileKra);
        editTextListOfItemsChangedEditPeofile = view.findViewById(R.id.editTextListOfItemsChangedEditPeofile);

        spinnerEditProfileGender = (Spinner) view.findViewById(R.id.spinnerEditProfileGender);

        Button buttonEditProfileSubmit = view.findViewById(R.id.ButtonEditProfileSubmit);

        tvEditProfileFullName.setText(user.getFullName());
        tvEditProfileDOB.setText(user.getUserDateofBirth());
        tvEditProfileRole.setText(user.getUserRole());
        //tvEditProfileStationName.setText(user.getUser);
        tvEditProfileJobGroup.setText(user.getUserJobGroup());
        tvEditProfileCounty.setText(user.getUserCounty());

        etEditProfilePhone.setText(user.getUserPhoneNumber());
        etEditProfileNHIF.setText(user.getUserNhifNumber());
        etEditProfileKra.setText(user.getUserKraPin());

        spinnerEditProfileGender.setSelection(getIndexByString(spinnerEditProfileGender, user.getUserGender()));

        //ssl security
        HttpsTrustManager.allowMINETSSL();

        buttonEditProfileSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                stringUsername = user.getUsername();
                stringPhone = etEditProfilePhone.getText().toString();
                stringNhif = etEditProfileNHIF.getText().toString();
                stringKra = etEditProfileKra.getText().toString();
                stringGender = spinnerEditProfileGender.getSelectedItem().toString();
                stringItemsChanged = editTextListOfItemsChangedEditPeofile.getText().toString();

                if(validateInputs()){
                    try {
                        EditProfileUser();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                
            }
        });

        

        return view;
    }

    /**
     * Display Progress bar while registering
     */
    private void displayLoader() {
        pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage("Submitting changes.. Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();

    }

    /**
     * Launch Dashboard Activity on Successful Sign Up
     */
     private void loadDashboard() {


     }

    private void EditProfileUser() throws JSONException {
        displayLoader();
        JSONObject request = new JSONObject();


            //Populate the request parameters
            request.put(KEY_USERNAME,stringUsername);
            request.put(KEY_PHONE_NUMBER, stringPhone);
            request.put(KEY_KRA_PIN, stringKra);
            request.put(KEY_GENDER, stringGender);
            request.put(KEY_NHIF_NUMBER, stringNhif);
            request.put(KEY_ITEMS_CHANGED, stringItemsChanged);



            
        String editprofile_url = "https://collaborationkenya.minet.com/minetapi/tsc/updateprofile ";
        JsonObjectRequest jsArrayRequest = new JsonObjectRequest
                (Request.Method.POST, editprofile_url, request, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        pDialog.dismiss();
                        try {
                            //Check if user got registered successfully
                            if (response.getInt(KEY_STATUS) == 0) {
                                //Set the user session
                                loadDashboard();
                                Toast.makeText(getActivity(), "Successfully changed", Toast.LENGTH_SHORT).show();

                            }else if(response.getInt(KEY_STATUS) == 1){
                                //Display error message if username is already existsing
                                Toast.makeText(getActivity(),"An error occurred", Toast.LENGTH_SHORT).show();


                            }else{
                                Toast.makeText(getActivity(),
                                        response.getString(KEY_MESSAGE), Toast.LENGTH_SHORT).show();

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pDialog.dismiss();

                        //Display error message whenever an error occurs
                        Toast.makeText(getActivity(),
                                error.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });

        // Access the RequestQueue through your singleton class.
        MySingleton.getInstance(getActivity()).addToRequestQueue(jsArrayRequest);
    }



    /**
     * Validates inputs and shows error if any
     * @return
     */
    private boolean validateInputs() {
    
        if (KEY_EMPTY.equals(stringPhone)) {
            etEditProfilePhone.setError("Phone Number cannot be empty");
            etEditProfilePhone.requestFocus();
            return false;
        }
        if (KEY_EMPTY.equals(stringNhif)) {
            etEditProfileNHIF.setError("NHIF cannot be empty");
            etEditProfileNHIF.requestFocus();
            return false;
        }
        if (KEY_EMPTY.equals(stringKra)) {
            etEditProfileKra.setError("KRA cannot be empty");
            etEditProfileKra.requestFocus();
            return false;
        }

        if (stringGender.equals("Gender")) {
            Toast.makeText(getActivity(), "Kindly choose your gender", Toast.LENGTH_SHORT).show();

            return false;
        }

        if (KEY_EMPTY.equals(stringItemsChanged)) {
            editTextListOfItemsChangedEditPeofile.setError("Items changed cannot be empty");
            editTextListOfItemsChangedEditPeofile.requestFocus();
            return false;
        }
    
    
        return true;
    }


/**
     * Populating spinner with a string value gotten from database
     *
     * @return
     */
    
    private int getIndexByString(Spinner spinner, String string) {
        int index = 0;
    
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(string)) {
                index = i;
                break;
            }
        }
        return index;
    }
}
