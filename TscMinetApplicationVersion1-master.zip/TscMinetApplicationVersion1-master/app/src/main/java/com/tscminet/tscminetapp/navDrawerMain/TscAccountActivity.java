package com.tscminet.tscminetapp.navDrawerMain;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import com.tscminet.tscminetapp.fragments.AddDependantFragment;
import com.tscminet.tscminetapp.fragments.RemoveDependantsFragment;
import com.tscminet.tscminetapp.fragments.ChangeOfDetailsFragment;
import com.tscminet.tscminetapp.fragments.ChronicDiseasesEnrollmentFragment;
import com.tscminet.tscminetapp.fragments.FeedbackFragment;
import com.tscminet.tscminetapp.fragments.HomeFragment;
import com.tscminet.tscminetapp.fragments.MedicalCoverLetterFragment;
import com.tscminet.tscminetapp.fragments.ReplaceDependantsFragment;
import com.tscminet.tscminetapp.fragments.TscWebsiteFragment;
import com.tscminet.tscminetapp.fragments.UnregisteredTeachersFragment;
import com.tscminet.tscminetapp.loginPage.SessionHandler;
import com.tscminet.tscminetapp.MainActivity;
import com.tscminet.tscminetapp.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.os.Handler;
import android.view.View;

import androidx.core.view.GravityCompat;
import androidx.appcompat.app.ActionBarDrawerToggle;

import android.view.MenuItem;

import com.google.android.material.navigation.NavigationView;
import com.tscminet.tscminetapp.loginPage.User;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.Menu;
import android.widget.TextView;
import android.widget.Toast;

public class TscAccountActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private SessionHandler session;

    public static boolean isMainActivityShown ;

    private static boolean isFragmentHomeShown =false ;
    private static boolean isFragmentChronicDiseasesEnrollmentShown=false ;

    private static boolean isFragmentHUnregisteredTeachersShown =false ;
    private static boolean isFragmentAddDependantShown=false ;
    private static boolean isFragmentChangeOfDetailsShown =false ;
    private static boolean isFragmentReplaceDependantsShown=false ;
    private static boolean isFragmentRemoveDependantsShown =false ;
    private static boolean isFragmentMedicalCoverLetterShown=false ;
    private static boolean isFragmentTscWebsiteShown =false ;
    private static boolean isFragmentFeedbackShown=false ;

    private boolean doubleBackToExitPressedOnce = false;


    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setTitle("Minet Insurance Brokers");

        session = new SessionHandler(getApplicationContext());
        User user = session.getUserDetails();

        /**
         * Call this function whenever you want to check user login
         * This will redirect user to LoginActivity is he is not
         * logged in
         * */
        // User user = session.getUserDetails();
        if (session.getUserDetails() == null) {
            //session.checkLogin();
            Intent intentmain = new Intent(TscAccountActivity.this,MainActivity.class);
            startActivity(intentmain);
            finish();
        }else{
            session.checkLogin();


        setContentView(R.layout.activity_tsc_account);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);


        View header = navigationView.getHeaderView(0);
        TextView NavHeaderTitle = (TextView) header.findViewById(R.id.nav_header_title);
        TextView NavHeaderSubTitle = (TextView) header.findViewById(R.id.nav_header_subtitle);
        NavHeaderTitle.setText(user.getFullName());
        NavHeaderSubTitle.setText(user.getUsername());

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        // Set the home as default
        Fragment fragment = new HomeFragment();
        //isFragment2Shown=false;
        isFragmentHomeShown =true;
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.screen_area, fragment)
                .commit();
        // Set the home as default selected or checked
        navigationView.getMenu().getItem(0).setChecked(true);

        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);

        }else if(isFragmentChronicDiseasesEnrollmentShown){
            FragmentBack(isFragmentChronicDiseasesEnrollmentShown);

        }else if(isFragmentHUnregisteredTeachersShown){
            FragmentBack(isFragmentHUnregisteredTeachersShown);

        }else if(isFragmentAddDependantShown){
            FragmentBack(isFragmentAddDependantShown);

        }else if(isFragmentChangeOfDetailsShown){
            FragmentBack(isFragmentChangeOfDetailsShown);

        }else if(isFragmentReplaceDependantsShown){
            FragmentBack(isFragmentReplaceDependantsShown);

        }else if(isFragmentRemoveDependantsShown){
            FragmentBack(isFragmentRemoveDependantsShown);

        }else if(isFragmentMedicalCoverLetterShown){
            FragmentBack(isFragmentMedicalCoverLetterShown);

        }else if(isFragmentTscWebsiteShown){
            FragmentBack(isFragmentTscWebsiteShown);

        }else if(isFragmentFeedbackShown){
            FragmentBack(isFragmentFeedbackShown);
        }

        else {
            doubleBackPress();

        }
    }

    private void doubleBackPress(){
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }


    private boolean FragmentBack (boolean fragShowing){
        // Set the home as default
        Fragment fragment = new HomeFragment();
        fragShowing = false;
        isFragmentHomeShown =true;
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.screen_area, fragment)
                .addToBackStack(null)
                .commit();
        // Set the home as default selected or checked
        navigationView.getMenu().getItem(0).setChecked(true);
        return fragShowing;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.tsc_account, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        Fragment fragment = null;
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        if (id == R.id.nav_home) {
            // Handle the camera action
            fragment = new HomeFragment();

        } else if (id == R.id.nav_Chronic_Diseases_Enrollment) {
            fragment = new ChronicDiseasesEnrollmentFragment();
            isFragmentChronicDiseasesEnrollmentShown=true;
            isFragmentHomeShown =false;

        } else if (id == R.id.nav_Unregistered_Teachers) {
            fragment = new UnregisteredTeachersFragment();

        } else if (id == R.id.nav_Add_Dependant) {
            fragment = new AddDependantFragment();

        } else if (id == R.id.nav_Change_of_Details) {
            fragment = new ChangeOfDetailsFragment();

        } else if (id == R.id.nav_Replace_Dependants) {
            fragment = new ReplaceDependantsFragment();

        } else if (id == R.id.nav_Remove_Dependants) {
            fragment = new RemoveDependantsFragment();

        } else if (id == R.id.nav_medical_cover_letter) {
            fragment = new MedicalCoverLetterFragment();

        } else if (id == R.id.nav_Tsc_website) {
            fragment = new TscWebsiteFragment();

        }else if (id == R.id.nav_Feedback) {
            fragment = new FeedbackFragment();

        } else if (id == R.id.nav_Log_Out) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Are you sure you want to log out?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {

                           session.logoutUser();
                            Intent i = new Intent(TscAccountActivity.this, MainActivity.class);
                            startActivity(i);
                            finish();
                            Toast.makeText(TscAccountActivity.this,"Successful Sign Out",Toast.LENGTH_LONG).show();
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();


        }
        if(fragment != null){
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction ft = fragmentManager.beginTransaction();

            //get the screens to change according to fragments
            ft.replace(R.id.screen_area,fragment);
           // ft.addToBackStack(null);

            ft.commit();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
