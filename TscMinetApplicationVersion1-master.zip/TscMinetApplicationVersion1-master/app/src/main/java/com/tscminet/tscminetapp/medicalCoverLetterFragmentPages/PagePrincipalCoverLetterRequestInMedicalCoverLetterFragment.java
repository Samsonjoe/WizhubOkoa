package com.tscminet.tscminetapp.medicalCoverLetterFragmentPages;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.tscminet.tscminetapp.R;
import com.tscminet.tscminetapp.loginPage.MySingleton;
import com.tscminet.tscminetapp.loginPage.SessionHandler;
import com.tscminet.tscminetapp.loginPage.User;

import org.json.JSONException;
import org.json.JSONObject;


public class PagePrincipalCoverLetterRequestInMedicalCoverLetterFragment extends Fragment {

    private static final String KEY_STATUS = "status";
    private static final String KEY_MESSAGE = "message";
    private static final String KEY_EMPTY = "";
    private static final String KEY_FULL_NAME = "FullName";
    private static final String KEY_REASON = "Reason";
    private static final String KEY_EMAIL = "Email";

    private static final String KEY_USERNAME = "username";
    private static final String KEY_PHONE = "PhoneNo";
    private static final String KEY_IDS = "DependantsIds" ;
    private SessionHandler session;
    private ProgressDialog pDialog;

    private String FullName_string;
    private String Reason_string;
    private String Email_string;
    private String Ids_string;
    private String Username_string;
    private String Phone_number_string;

    private EditText etReason_typed;
    private EditText etEmail_typed;

    private TextView tvFullName;
    private TextView tvPhone;
    private TextView tvIds;
    private TextView textViewPrincipleNameInMedicalCover;


    private String request_medical_cover_url = "https://collaborationkenya.minet.com/MinetAPI/tsc/RequestMedicalCover";


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_pageprinciplecoverletterrequestinmedicalcoverletterfragment, container, false);

        session = new SessionHandler(getActivity().getApplicationContext());
        User user = session.getUserDetails();

        textViewPrincipleNameInMedicalCover = (TextView) view.findViewById(R.id.textViewPrincipleNameInMedicalCover);
        tvFullName =(TextView) view.findViewById(R.id.TXTview_fullName_medical_PRINCIPAL);
        tvPhone =(TextView) view.findViewById(R.id.TXTview_phone_number_medical_PRINCIPAL);
        tvIds =(TextView) view.findViewById(R.id.TXTview_id_number_medical_PRINCIPAL);

        etEmail_typed = (EditText) view.findViewById(R.id.EDITTEXT_EmailAddressCoverRequestPRINCIPAL);
        etReason_typed = (EditText) view.findViewById(R.id.EDITTEXT_ReasonForRequestCoverRequestPRINCIPAL);



        textViewPrincipleNameInMedicalCover.setText(user.getFullName());
        tvFullName.setText(user.getFullName());
        tvPhone.setText(user.getUserPhoneNumber());
        tvIds.setText(user.getUserIdNumber());



        Button SubmitMedicalCoverRequest = view.findViewById(R.id.btnSubmitMedicalCoverRequestPRINCIPAL);
        SubmitMedicalCoverRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                User user = session.getUserDetails();


                FullName_string = user.getFullName() ;
                Email_string = etEmail_typed.getText().toString().trim();
                Reason_string = etReason_typed.getText().toString().trim();
                Ids_string = user.getUserIdNumber();
                Username_string = user.getUsername();
                Phone_number_string= user.getUserPhoneNumber();
                if (validateInputs()) {
                    request_claim();

                }
            }
        });

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }



    /**
     * Display Progress bar while Logging in
     */

    private void displayLoader() {
        pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage("Sending Request.. Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();

    }

    private void request_claim() {
        displayLoader();
        JSONObject request = new JSONObject();
        try {

            //Populate the request parameters
            request.put(KEY_FULL_NAME, FullName_string);
            request.put(KEY_REASON, Reason_string);
            request.put(KEY_EMAIL, Email_string);
            request.put(KEY_IDS, Ids_string);
            request.put(KEY_USERNAME, Username_string);
            request.put(KEY_PHONE, Phone_number_string);


        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest jsArrayRequestMedical = new JsonObjectRequest
                (Request.Method.POST, request_medical_cover_url, request, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        pDialog.dismiss();
                        try {
                            //Check if user got logged in successfully

                            if (response.getInt(KEY_STATUS) == 0) {

                                Toast.makeText(getActivity().getApplicationContext(),
                                        "Kindly confirm via text sent ", Toast.LENGTH_SHORT).show();

                            }else{
                                Toast.makeText(getActivity().getApplicationContext(),
                                        "Kindly confirm via text sent ", Toast.LENGTH_SHORT).show();

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pDialog.dismiss();

                        //Display error message whenever an error occurs
                        Toast.makeText(getActivity().getApplicationContext(),
                                error.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });


        // Access the RequestQueue through your singleton class.
        MySingleton.getInstance(getActivity()).addToRequestQueue(jsArrayRequestMedical);
    }

    /**
     * Validates inputs and shows error if any
     * @return
     */
    private boolean validateInputs() {

        if(KEY_EMPTY.equals(Email_string)){
            etEmail_typed.setError("Email Address cannot be empty");
            etEmail_typed.requestFocus();
            return false;
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(Email_string).matches()) {
            etEmail_typed.setError("enter a valid email address");
            etEmail_typed.requestFocus();
            return false;
        }
        if (KEY_EMPTY.equals(Reason_string)) {
            etReason_typed.setError("Reason cannot be empty");
            etReason_typed.requestFocus();
            return false;

        }
        return true;
    }


}
