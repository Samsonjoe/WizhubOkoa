package com.tscminet.tscminetapp.fragments;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.tscminet.tscminetapp.R;
import com.tscminet.tscminetapp.loginPage.SessionHandler;
import com.tscminet.tscminetapp.loginPage.User;
import com.tscminet.tscminetapp.utils.HttpsTrustManager;
import com.tscminet.tscminetapp.utils.MailSenderAttachment;
import com.tscminet.tscminetapp.utils.Permissions;

import static android.app.Activity.RESULT_OK;

public class AddDependantFragment extends androidx.fragment.app.Fragment {


    private static final String KEY_STATUS = "status";
    private static final String KEY_MESSAGE = "message";
    private static final String KEY_EMPTY = "";

    private static final String  KEY_DEPENDANT_NAME = "DependantName";
    private static final String KEY_DEPENDANT_RELATIONSHIP = "DependantRelationship";
    private static final String KEY_DEPENDANT_GENDER = "Gender";
    private static final String KEY_DATE_OF_BIRTH = "DependantBirthDate" ;
    private static final String KEY_DEPENDANT_DISABILITY = "Disabled";
    private static final String KEY_DEPENDANT_PHONE= "MobileNumber";
    private static final String KEY_DEPENDANT_ID = "DependantsIds" ;
    private static final String KEY_DEPENDANT_ID_NUMBER = "IdNumber" ;
    private static final String KEY_USERNAME ="Username";


    private static final String KEY_LIST_ITEMS_ = "List" ;

    private static final int PICK_PHOTO = 1958;

    private SessionHandler session;

    private ProgressDialog mProgressDialog;
    private EditText fName,sName,Lname,birthDate,phone,idNumber,etFilePicked;
    private Spinner county,status,condition,documentType;

    String  fNameString,sNameString,LnameString,birthDateString,phoneString,idNumberString,
            countyString,statusString,conditionString,documentTypeString;

    String uploadFileName,FilePickedPathString;

    Uri URI = null;

     ProgressDialog please_wait;
    private static final int VERIFY_PERMISSIONS_REQUEST = 1;

    public AddDependantFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //final View view = inflater.inflate(R.layout.fragment_add_dependant, container, false);
        final View view = inflater.inflate(R.layout.layout_deactivated_pages, container, false);

        session = new SessionHandler(getActivity().getApplicationContext());

        /* User user = session.getUserDetails();

        fName = (EditText) view.findViewById(R.id.etAddDependantFirstName);
        sName = (EditText) view.findViewById(R.id.etAddDependantSecondName);
        Lname = (EditText) view.findViewById(R.id.etAddDependantLastName);
        birthDate = (EditText) view.findViewById(R.id.etAddDependantDOB);
        phone = (EditText) view.findViewById(R.id.etDependantsPhone);
        idNumber = (EditText) view.findViewById(R.id.etDependantId);

        county = (Spinner) view.findViewById(R.id.spinnerDependantCounty);
        status = (Spinner) view.findViewById(R.id.spinnerDependantStatus);
        condition = (Spinner) view.findViewById(R.id.spinnerDependantCondition);

        documentType = (Spinner) view.findViewById(R.id.spinnerDependantDocUpload);

        etFilePicked =(EditText) view.findViewById(R.id.etFilePicked);

        if(checkPermissionArray(Permissions.PERMISSIONS)){
           // Toast.makeText(getActivity(), "Permission Granted", Toast.LENGTH_SHORT).show();
        }else{
            verifyPermissions(Permissions.PERMISSIONS);
            Toast.makeText(getActivity(), "Please check permissions", Toast.LENGTH_SHORT).show();
        }

        //ssl security
        HttpsTrustManager.allowMINETSSL();

        Button btnChooseClaimFile = view.findViewById(R.id.buttonAttachDependantfileinNewDependant);
        btnChooseClaimFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*//*");*/

              /* startActivityForResult(intent, PICK_PHOTO);

            }
        });

        Button BtnAddDependant = view.findViewById(R.id.BtnAddDependant);
        BtnAddDependant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Show progress dialog while sending email


                fNameString = fName.getText().toString().trim();
                sNameString = sName.getText().toString().trim();
                LnameString = Lname.getText().toString().trim();
                birthDateString = birthDate.getText().toString().trim();
                countyString = county.getSelectedItem().toString().trim();
                statusString = status.getSelectedItem().toString().trim();
                conditionString= condition.getSelectedItem().toString().trim();
                phoneString= phone.getText().toString().trim();
                idNumberString= idNumber.getText().toString().trim();
                documentTypeString= documentType.getSelectedItem().toString().trim();
                FilePickedPathString = etFilePicked.getText().toString().trim();

                if (validateInputs()) {

                    mProgressDialog = ProgressDialog.show(getActivity(),"New Dependant request is being sent", "Please wait...",false,true);

                    // String mail = emailSignup.getText().toString().trim();
                    User user = session.getUserDetails();
                    final String mail = "samnjoroge6035@gmail.com";
                    final String SubjectMain= "TSC APP ADD NEW DEPENDANT TEST";
                    final String filePathMail =uploadFileName;
                    final String DeacriptionMAIN ="ADD dependant request from "+user.getFullName()+"\n\n TSC Number : "+user.getUsername()+"\n\n Dependant to be added details " +
                            "\n First Name : "+fNameString+
                            "\n Second Name : "+sNameString+
                            "\n Last Name : "+LnameString+
                            "\n Birth Date : "+birthDateString+
                            "\n County : "+countyString+
                            "\n Status : "+statusString+
                            "\n condition : "+conditionString+
                            "\n Phone Number : "+phoneString+
                            "\n Id number : "+idNumberString+
                            "\n\nKind Regards from ,\n"+user.getFullName();



                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                MailSenderAttachment sender = new MailSenderAttachment("minetinsurancekenya@gmail.com",
                                        "minetkenya2019");
                                sender.sendMail(SubjectMain,DeacriptionMAIN,filePathMail,
                                        "minetinsurancekenya@gmail.com", mail);

                              //  Toast.makeText(getActivity(), "SUCCESS", Toast.LENGTH_SHORT).show();
                                mProgressDialog.dismiss();
                            } catch (Exception e) {
                                Log.e("SendMail", e.getMessage(), e);
                              //  Toast.makeText(getActivity(), "FAILED", Toast.LENGTH_SHORT).show();
                                mProgressDialog.dismiss();
                            }
                        }

                    }).start();
                    //end
                    fName.getText().clear();
                    sName.getText().clear();
                    Lname.getText().clear();
                    phone.getText().clear();
                    idNumber.getText().clear();

                }

              /*  Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    public void run() {
                        mProgressDialog.dismiss();
                        Toast.makeText(getActivity(), "New dependant request sent", Toast.LENGTH_SHORT).show();
                    }
                }, 4000); // 3000 milliseconds delay

            }
        });*/

        return view;
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub


        if(resultCode==RESULT_OK){

            Uri selectedImmage = data.getData();
            String[] filePathColumn ={MediaStore.Images.Media.DATA};

            Cursor cursor = getActivity().getContentResolver().query(selectedImmage,filePathColumn,null,null,null);
            // columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            uploadFileName = cursor.getString(column_index);
            // Log.e("Attachment Path:",uploadFileName);

            URI = Uri.parse("file://"+uploadFileName);
            cursor.close();






            //uploadFileName =  data.getData().getPath();
            // uploadFilePath = data.getData().getPath();


            etFilePicked.setText(uploadFileName);
            Toast.makeText(getActivity(), uploadFileName , Toast.LENGTH_LONG).show();

        }
    }


    /**
     * Check an array of permissions
     * @param permissions
     * @return
     */

    public boolean checkPermissionArray(String[] permissions) {
       // Log.d(TAG, "checkPermissionArray: checking permissions array.");

        for (int i = 0; i<permissions.length; i++){
            String check = permissions[i];
            if(!checkPermissions(check)){
                return false;
            }
        }
        return true;
    }

    /**
     * Check a single permission it has been verified
     * @param permission
     * @return
     */
    public boolean checkPermissions(String permission) {
       // Log.d(TAG, "checkPermissions: checking permission " + permission);

        int permissionRequest = ActivityCompat.checkSelfPermission(getActivity(), permission);

        if(permissionRequest != PackageManager.PERMISSION_GRANTED){
          //  Log.d(TAG, "checkPermissions: \n Permission wa not granted for: " + permission);
            return false;
        }
        else{
          //  Log.d(TAG, "checkPermissions: \n permission was granted for: " + permission);
            return true;
        }
    }


    /***
     * verify all the permissions passed to the array
     * @param permissions
     */
    private void verifyPermissions(String[] permissions) {
      //  Log.d(TAG, "verifyPermissions: verifying permissions.");

        ActivityCompat.requestPermissions(
                getActivity(),
                permissions,
                VERIFY_PERMISSIONS_REQUEST
        );
    }

    /**
     * Validates inputs and shows error if any
     * @return
     */
    private boolean validateInputs() {

        if (KEY_EMPTY.equals(fNameString)) {
            fName.setError("First name cannot be empty");
            fName.requestFocus();
            return false;
        }
        if (KEY_EMPTY.equals(sNameString)) {
            sName.setError("Second name cannot be empty");
            sName.requestFocus();
            return false;

        }
        if (KEY_EMPTY.equals(LnameString)) {
            Lname.setError("Last name cannot be empty");
            Lname.requestFocus();
            return false;
        }
        if (KEY_EMPTY.equals(birthDateString)) {
            birthDate.setError("Birth date cannot be empty");
            birthDate.requestFocus();
            return false;
        }
        if (KEY_EMPTY.equals(phoneString)) {
            phone.setError("Phone number cannot be empty");
            phone.requestFocus();
            return false;
        }
        if (KEY_EMPTY.equals(documentTypeString)) {
            Toast.makeText(getActivity(), "Kindly attach an Image file", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }



}


