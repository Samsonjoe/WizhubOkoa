package com.tscminet.tscminetapp.retrofit_modelClass;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class ImageSenderInfo implements Parcelable {

    @SerializedName("sender_disabled")
    private String Disability;
    @SerializedName("sender_posdate")
    private String proofOfSchoolExpiryDate;

    @SerializedName("TSCNo")
    private String TSCNo;
    @SerializedName("FullName")
    private String FullName;

    @SerializedName("Phone")
    private String Phone;

    @SerializedName("DependantType")
    private String DependantType;
    @SerializedName("DOB")
    private String DOB;
    @SerializedName("IdNo")
    private String IdNo;


    public ImageSenderInfo() {
    }

    public ImageSenderInfo(String Disability, String proofOfSchoolExpiryDate, String TSCNo, String FullName, String Phone, String DependantType, String DOB, String IdNo) {
        this.Disability = Disability;
        this.proofOfSchoolExpiryDate = proofOfSchoolExpiryDate;

        this.TSCNo = TSCNo;
        this.FullName = FullName;
        this.Phone = Phone;
        this.DependantType = DependantType;
        this.DOB = DOB;
        this.IdNo = IdNo;

    }

    public final static Creator<ImageSenderInfo> CREATOR = new Creator<ImageSenderInfo>() {

        @SuppressWarnings({
                "unchecked"
        })
        public ImageSenderInfo createFromParcel(Parcel in) {
            ImageSenderInfo instance = new ImageSenderInfo();
            instance.Disability = ((String) in.readValue((String.class.getClassLoader())));
            instance.proofOfSchoolExpiryDate = ((String) in.readValue((int.class.getClassLoader())));

            instance.TSCNo = ((String) in.readValue((String.class.getClassLoader())));
            instance.FullName = ((String) in.readValue((String.class.getClassLoader())));
            instance.Phone = ((String) in.readValue((String.class.getClassLoader())));
            instance.DependantType = ((String) in.readValue((String.class.getClassLoader())));
            instance.DOB = ((String) in.readValue((String.class.getClassLoader())));
            instance.IdNo = ((String) in.readValue((String.class.getClassLoader())));


            return instance;
        }

        public ImageSenderInfo[] newArray(int size) {
            return (new ImageSenderInfo[size]);
        }

    };


    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(Disability);
        dest.writeValue(proofOfSchoolExpiryDate);

        dest.writeValue(TSCNo);
        dest.writeValue(FullName);
        dest.writeValue(Phone);
        dest.writeValue(DependantType);
        dest.writeValue(DOB);
        dest.writeValue(IdNo);

    }

    public int describeContents() {
        return  0;
    }

}