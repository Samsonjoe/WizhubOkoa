package com.tscminet.tscminetapp.fragments;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.tscminet.tscminetapp.R;
import com.tscminet.tscminetapp.changeOfDetailsFragmentPages.PageChangeDetailsInChangeOfDetailsFragment;
import com.tscminet.tscminetapp.loginPage.SessionHandler;
import com.tscminet.tscminetapp.loginPage.User;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

public class ChangeOfDetailsFragment extends androidx.fragment.app.Fragment {

    public ChangeOfDetailsFragment(){
        // Required empty public constructor
    }

    private String TAG = ChangeOfDetailsFragment.class.getSimpleName();
    private ListView lv;


    //JSON Node Names
    private static final String  KEY_DEPENDANT_NAME = "DependantName";
    private static final String KEY_DEPENDANT_RELATIONSHIP = "DependantRelationship";
    private static final String KEY_DEPENDANT_GENDER = "Gender";
    private static final String KEY_DATE_OF_BIRTH = "DependantBirthDate" ;

    private static final String KEY_DEPENDANT_DISABILITY = "Disabled";
    private static final String KEY_DEPENDANT_PHONE= "MobileNumber";
    private static final String KEY_DEPENDANT_ID = "DependantsIds" ;

    private static final String KEY_DEPENDANT_ID_NUMBER = "IdNumber" ;


    private SessionHandler session;
    private ArrayList<HashMap<String, String>> dependantList;
    private ProgressBar spinner;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_change_of_details, container, false);
        session = new SessionHandler(getActivity().getApplicationContext());




        dependantList = new ArrayList<>();
        lv = (ListView) view.findViewById(R.id.records_view_fragment_change_details);

        spinner =(ProgressBar)view.findViewById(R.id.progressBarChangeDetails);
        spinner.setVisibility(View.VISIBLE);

        new GetDependantsChangeDetails().execute();

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }
    private class GetDependantsChangeDetails extends AsyncTask<Void, Void, Void> {


        @Override
        protected Void doInBackground(Void... arg0) {

            User user = session.getUserDependants();
            String name =user.getUserDependants();
            String jsonStr = name;

            Log.e(TAG, "Response from url: " + jsonStr);
            if(dependantList.isEmpty()) {
                if (jsonStr != null) {
                    try {
                        JSONObject jsonObj = new JSONObject(jsonStr);

                        // Getting JSON Array node
                        JSONArray dependants = jsonObj.getJSONArray("Dependants");

                        // looping through All Contacts
                        for (int i = 0; i < dependants.length(); i++) {

                            JSONObject c = dependants.getJSONObject(i);

                            // String policy_id = c.getString("");
                            String dependant_name = c.getString(KEY_DEPENDANT_NAME);
                            String relationship = c.getString(KEY_DEPENDANT_RELATIONSHIP);
                            String gender = c.getString(KEY_DEPENDANT_GENDER);
                            String date_of_birth = c.getString(KEY_DATE_OF_BIRTH);
                            String disabled = c.getString(KEY_DEPENDANT_DISABILITY);
                            String phone = c.getString(KEY_DEPENDANT_PHONE);
                            String dependant_id = c.getString(KEY_DEPENDANT_ID);
                            String dependant_id_number = c.getString(KEY_DEPENDANT_ID_NUMBER);



                            // tmp hash map for single dependant
                            HashMap<String, String> dependant = new HashMap<>();

                            // adding each child node to HashMap key => value
                            dependant.put(KEY_DEPENDANT_NAME, dependant_name);
                            dependant.put(KEY_DEPENDANT_RELATIONSHIP, relationship);
                            dependant.put(KEY_DEPENDANT_GENDER, gender);
                            dependant.put(KEY_DATE_OF_BIRTH, date_of_birth);
                            dependant.put(KEY_DEPENDANT_DISABILITY, disabled);
                            dependant.put(KEY_DEPENDANT_PHONE, phone);
                            dependant.put(KEY_DEPENDANT_ID, dependant_id);
                            dependant.put(KEY_DEPENDANT_ID_NUMBER, dependant_id_number);

                            dependantList.add(dependant);
                        }
                    } catch (final JSONException e) {
                        Log.e(TAG, "Json parsing error: " + e.getMessage());
                        Objects.requireNonNull(getActivity()).runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getActivity().getApplicationContext(),
                                        "Json parsing error: " + e.getMessage(),
                                        Toast.LENGTH_LONG).show();
                            }
                        });

                    }

                } else {
                    Log.e(TAG, "Couldn't get json from server.");
                    Objects.requireNonNull(getActivity()).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getActivity().getApplicationContext(),
                                    "Couldn't get json from server. Check LogCat for possible errors!",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            if (getActivity() != null) {
                // Code goes here.
                ListAdapter adapter = new SimpleAdapter(getActivity(), dependantList,
                        R.layout.list_item_change_of_details_fragment, new String[]{ KEY_DEPENDANT_NAME, KEY_DATE_OF_BIRTH, KEY_DEPENDANT_RELATIONSHIP},
                        new int[]{ R.id.name_CHANGEDETAILS,R.id.date_added_CHANGEDETAILS,
                                R.id.relationship_CHANGEDETAILS});


                lv.setAdapter(adapter);
            }

            ListUtils.setDynamicHeight(lv);
            spinner.setVisibility(View.GONE);

            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    String dependant_name = dependantList.get(i).get(KEY_DEPENDANT_NAME);
                    String dependant_dob = dependantList.get(i).get(KEY_DATE_OF_BIRTH);
                    String dependant_gender = dependantList.get(i).get(KEY_DEPENDANT_GENDER);
                    String dependant_disability = dependantList.get(i).get(KEY_DEPENDANT_DISABILITY);
                    String dependant_relationship = dependantList.get(i).get(KEY_DEPENDANT_RELATIONSHIP);
                    String dependant_phone = dependantList.get(i).get(KEY_DEPENDANT_PHONE);
                    String dependant_id = dependantList.get(i).get(KEY_DEPENDANT_ID);
                    String dependant_id_number = dependantList.get(i).get(KEY_DEPENDANT_ID_NUMBER);


                    Fragment changeDetailsFrag = new PageChangeDetailsInChangeOfDetailsFragment();
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.screen_area, changeDetailsFrag);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();


                    //Get the clicked items to pass to PolicyDetailsinRenewPolicyInRenewPolicyFragment class
                    Bundle bundleChangeDetails = new Bundle();
                    bundleChangeDetails.putString(KEY_DEPENDANT_NAME, dependant_name);
                    bundleChangeDetails.putString(KEY_DATE_OF_BIRTH, dependant_dob);
                    bundleChangeDetails.putString(KEY_DEPENDANT_GENDER, dependant_gender);
                    bundleChangeDetails.putString(KEY_DEPENDANT_DISABILITY, dependant_disability);
                    bundleChangeDetails.putString(KEY_DEPENDANT_RELATIONSHIP, dependant_relationship);
                    bundleChangeDetails.putString(KEY_DEPENDANT_PHONE, dependant_phone);
                    bundleChangeDetails.putString(KEY_DEPENDANT_ID, dependant_id);
                    bundleChangeDetails.putString(KEY_DEPENDANT_ID_NUMBER, dependant_id_number);

                    changeDetailsFrag.setArguments(bundleChangeDetails);
                    // Toast.makeText(getActivity(),"Pic"+i+l+"Selected",Toast.LENGTH_SHORT).show();
                }
            });

        }
    }


    public static class ListUtils {
        public static void setDynamicHeight(ListView mListView) {
            ListAdapter mListAdapter = mListView.getAdapter();
            if (mListAdapter == null) {
                // when adapter is null
                return;
            }
            int height = 0;
            int desiredWidth = View.MeasureSpec.makeMeasureSpec(mListView.getWidth(), View.MeasureSpec.UNSPECIFIED);
            for (int i = 0; i < mListAdapter.getCount(); i++) {
                View listItem = mListAdapter.getView(i, null, mListView);
                listItem.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
                height += listItem.getMeasuredHeight();
            }
            ViewGroup.LayoutParams params = mListView.getLayoutParams();
            params.height = height + (mListView.getDividerHeight() * (mListAdapter.getCount() - 1));
            mListView.setLayoutParams(params);
            mListView.requestLayout();
        }
    }
}
