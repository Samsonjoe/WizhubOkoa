package com.tscminet.tscminetapp.fragments;


import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.tscminet.tscminetapp.loginPage.SessionHandler;
import com.tscminet.tscminetapp.loginPage.User;
import com.tscminet.tscminetapp.R;
import com.tscminet.tscminetapp.medicalCoverLetterFragmentPages.PageCoverLetterRequestInMedicalCoverLetterFragment;
import com.tscminet.tscminetapp.medicalCoverLetterFragmentPages.PagePrincipalCoverLetterRequestInMedicalCoverLetterFragment;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class MedicalCoverLetterFragment extends androidx.fragment.app.Fragment {

    public MedicalCoverLetterFragment(){
        // Required empty public constructor
    }

    private SessionHandler session;
    private ArrayList<HashMap<String, String>> dependantList;
    private String TAG = MedicalCoverLetterFragment.class.getSimpleName();
    private ListView lv;

    //JSON Node Names
    private static final String  KEY_DEPENDANT_NAME = "DependantName";
    private static final String KEY_DEPENDANT_DATE_OF_BIRTH = "DependantBirthDate" ;
    private static final String KEY_DEPENDANT_GENDER = "Gender";
    private static final String KEY_DEPENDANT_DISABLED = "Disabled";
    private static final String KEY_DEPENDANT_RELATIONSHIP = "DependantRelationship";
    private static final String KEY_DEPENDANT_PHONE = "MobileNumber" ;
    private static final String KEY_DEPENDANT_IDS = "DependantsIds" ;

    private static final String KEY_DEPENDANT_STATUS = "DependantStatus";
    private static final String KEY_DATE_ADDED = "DependantDateAdded" ;

    private Button btnPrincipleCoverLetter;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_medical_cover_letter, container, false);

        session = new SessionHandler(getActivity().getApplicationContext());

        btnPrincipleCoverLetter = (Button)view.findViewById(R.id.btnPrincipleCoverLetter);
        btnPrincipleCoverLetter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Fragment renewPolicyfragment = new PagePrincipalCoverLetterRequestInMedicalCoverLetterFragment();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.screen_area, renewPolicyfragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();

            }
        });

        dependantList = new ArrayList<>();
        lv = (ListView) view.findViewById(R.id.records_view_dependants_medical_cover_fragment);

        new GetDependants().execute();


        return view;
    }


    private class GetDependants extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
           // Toast.makeText(getActivity(),"Json Data is downloading",Toast.LENGTH_LONG).show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {

            User user = session.getUserDependants();
            String name =user.getUserDependants();
            String jsonStr = name;

            Log.e(TAG, "Response from url: " + jsonStr);
            if(dependantList.isEmpty()) {
                if (jsonStr != null) {
                    try {
                        JSONObject jsonObj = new JSONObject(jsonStr);
                        // Getting JSON Array node
                        JSONArray dependants = jsonObj.getJSONArray("Dependants");
                        // looping through All dependants
                        for (int i = 0; i < dependants.length(); i++) {

                            JSONObject c = dependants.getJSONObject(i);

                            String dependant_full_name = c.getString(KEY_DEPENDANT_NAME);
                            String dependant_relationship = c.getString(KEY_DEPENDANT_RELATIONSHIP);
                            String dependant_status = c.getString(KEY_DEPENDANT_STATUS);
                            String dependant_date_added = c.getString(KEY_DATE_ADDED);
                            String dependant_date_of_birth = c.getString(KEY_DEPENDANT_DATE_OF_BIRTH);
                            String dependant_gender = c.getString(KEY_DEPENDANT_GENDER);
                            String dependant_disabled = c.getString(KEY_DEPENDANT_DISABLED);
                            String dependant_phone = c.getString(KEY_DEPENDANT_PHONE);
                            String dependant_ids = c.getString(KEY_DEPENDANT_IDS);

                            // tmp hash map for single dependant
                            HashMap<String, String> dependant = new HashMap<>();

                            // adding each child node to HashMap key => value
                            dependant.put(KEY_DEPENDANT_NAME, dependant_full_name);
                            dependant.put(KEY_DEPENDANT_RELATIONSHIP, dependant_relationship);
                            dependant.put(KEY_DEPENDANT_STATUS, dependant_status);
                            dependant.put(KEY_DATE_ADDED, dependant_date_added);
                            dependant.put(KEY_DEPENDANT_DATE_OF_BIRTH, dependant_date_of_birth);
                            dependant.put(KEY_DEPENDANT_GENDER, dependant_gender);
                            dependant.put(KEY_DEPENDANT_DISABLED, dependant_disabled);
                            dependant.put(KEY_DEPENDANT_PHONE, dependant_phone);
                            dependant.put(KEY_DEPENDANT_IDS, dependant_ids);

                            dependantList.add(dependant);

                        }
                    } catch (final JSONException e) {
                        Log.e(TAG, "Json parsing error: " + e.getMessage());
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getActivity().getApplicationContext(),
                                        "Json parsing error: " + e.getMessage(),
                                        Toast.LENGTH_LONG).show();
                            }
                        });

                    }

                } else {
                    Log.e(TAG, "Couldn't get json from server.");
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getActivity().getApplicationContext(),
                                    "Couldn't get json from server. Check LogCat for possible errors!",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            if (getActivity() != null) {
                // Code goes here.
                ListAdapter adapter = new SimpleAdapter(getActivity(), dependantList,
                        R.layout.list_item_medical_cover_letter_fragment, new String[]{ KEY_DEPENDANT_NAME,KEY_DATE_ADDED,KEY_DEPENDANT_RELATIONSHIP},
                        new int[]{ R.id.dependant_name_FRAGMEDICALLETTER,
                                R.id.dependant_date_added_FRAGMEDICALLETTER,R.id.dependant_relationship_FRAGMEDICALLETTER});



                lv.setAdapter(adapter);


            }

            ListUtils.setDynamicHeight(lv);



            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {




                    String dep_full_name = dependantList.get(i).get(KEY_DEPENDANT_NAME);
                    String dep_date_of_birth = dependantList.get(i).get(KEY_DEPENDANT_DATE_OF_BIRTH);
                    String dep_gender = dependantList.get(i).get(KEY_DEPENDANT_GENDER);
                    String dep_disabled = dependantList.get(i).get(KEY_DEPENDANT_DISABLED);
                    String dep_relationship = dependantList.get(i).get(KEY_DEPENDANT_RELATIONSHIP);
                    String dep_mobile = dependantList.get(i).get(KEY_DEPENDANT_PHONE);
                    String dep_ids = dependantList.get(i).get(KEY_DEPENDANT_IDS);



                    Fragment renewPolicyfragment = new PageCoverLetterRequestInMedicalCoverLetterFragment();
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.screen_area, renewPolicyfragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();

                    //Get the clicked items to pass to PolicyDetailsinRenewPolicyInRenewPolicyFragment class
                    Bundle bundlerenewPolicy = new Bundle();
                    bundlerenewPolicy.putString(KEY_DEPENDANT_NAME, dep_full_name);
                    bundlerenewPolicy.putString(KEY_DEPENDANT_DATE_OF_BIRTH, dep_date_of_birth);
                    bundlerenewPolicy.putString(KEY_DEPENDANT_GENDER, dep_gender);
                    bundlerenewPolicy.putString(KEY_DEPENDANT_DISABLED, dep_disabled);
                    bundlerenewPolicy.putString(KEY_DEPENDANT_RELATIONSHIP, dep_relationship);
                    bundlerenewPolicy.putString(KEY_DEPENDANT_PHONE, dep_mobile);
                    bundlerenewPolicy.putString(KEY_DEPENDANT_IDS, dep_ids);

                    renewPolicyfragment.setArguments(bundlerenewPolicy);

                    //Toast.makeText(getActivity(),"Pic"+i+l+"Selected",Toast.LENGTH_SHORT).show();

                }
            });

        }
    }


    public static class ListUtils {
        public static void setDynamicHeight(ListView mListView) {
            ListAdapter mListAdapter = mListView.getAdapter();
            if (mListAdapter == null) {
                // when adapter is null

                return;
            }
            int height = 0;
            int desiredWidth = View.MeasureSpec.makeMeasureSpec(mListView.getWidth(), View.MeasureSpec.UNSPECIFIED);
            for (int i = 0; i < mListAdapter.getCount(); i++) {
                View listItem = mListAdapter.getView(i, null, mListView);
                listItem.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
                height += listItem.getMeasuredHeight();
            }
            ViewGroup.LayoutParams params = mListView.getLayoutParams();
            params.height = height + (mListView.getDividerHeight() * (mListAdapter.getCount() - 1));
            mListView.setLayoutParams(params);
            mListView.requestLayout();
        }
    }
}
