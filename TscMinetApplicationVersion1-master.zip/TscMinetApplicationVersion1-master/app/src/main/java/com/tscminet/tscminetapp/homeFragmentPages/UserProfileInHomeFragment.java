package com.tscminet.tscminetapp.homeFragmentPages;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.tscminet.tscminetapp.loginPage.SessionHandler;
import com.tscminet.tscminetapp.loginPage.User;
import com.tscminet.tscminetapp.R;

public class UserProfileInHomeFragment extends androidx.fragment.app.Fragment {
    Button Button_Edit_Profile;

    private TextView textViewFullName;
    private TextView textViewTscNumber;
    private TextView textViewJobGroup;
    private TextView textViewIdNumber;
    private TextView textViewCellphone;
    private TextView textViewKraPin;
    private TextView textViewNhif;
    private TextView textViewStationName;
    private TextView textViewCounty ;

    private SessionHandler session;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        session = new SessionHandler(getActivity().getApplicationContext());
        User user = session.getUserDetails();

        View view = inflater.inflate(R.layout.fragment_user_profile_in_home_fragment,container,false);

        textViewFullName = view.findViewById(R.id.etNameWRITEPROFILE);
        textViewTscNumber = view.findViewById(R.id.tsc_numberWRITEPROFILE);
        textViewJobGroup = view.findViewById(R.id.job_GroupWRITEPROFILE);
        textViewIdNumber = view.findViewById(R.id.id_NumberWRITEPROFILE);
        textViewCellphone = view.findViewById(R.id.cell_PhoneWRITEPROFILE);
        textViewKraPin = view.findViewById(R.id.KRA_Pin_NumberWRITEPROFILE);
        textViewNhif = view.findViewById(R.id.NHIF_WRITEPROFILE);
        textViewStationName = view.findViewById(R.id.stationNameWRITEPROFILE);
        textViewCounty = view.findViewById(R.id.CountyWRITEPROFILE);


        textViewFullName.setText(user.getFullName());
        textViewTscNumber.setText(user.getUsername());
        textViewJobGroup.setText(user.getUserJobGroup());
        textViewIdNumber.setText(user.getUserIdNumber());
        textViewCellphone.setText(user.getUserPhoneNumber());
        textViewKraPin.setText(user.getUserKraPin());
        textViewNhif.setText(user.getUserNhifNumber());
        textViewStationName.setText(user.getUserCounty());
        textViewCounty.setText(user.getUserCounty());

        Button_Edit_Profile = view.findViewById(R.id.buttonEditMyProfileDetails);



        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Button_Edit_Profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment fragment = new EditProfileInUserProfileInHomeFragment();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.screen_area, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }

        });
    }
}
