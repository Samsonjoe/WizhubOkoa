package com.tscminet.tscminetapp.loginPage;

public class Utils {

    //This is your from email
    public static final String EMAIL = "minetonlinekenya@gmail.com";

    //This is your from email password
    public static final String PASSWORD = "minet2019";


}
