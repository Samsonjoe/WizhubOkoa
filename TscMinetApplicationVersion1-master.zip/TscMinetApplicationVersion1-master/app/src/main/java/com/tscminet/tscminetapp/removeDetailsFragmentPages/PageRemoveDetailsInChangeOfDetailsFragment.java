package com.tscminet.tscminetapp.removeDetailsFragmentPages;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.tscminet.tscminetapp.R;
import com.tscminet.tscminetapp.loginPage.MySingleton;
import com.tscminet.tscminetapp.loginPage.SessionHandler;
import com.tscminet.tscminetapp.loginPage.User;
import com.tscminet.tscminetapp.utils.HttpsTrustManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;


public class PageRemoveDetailsInChangeOfDetailsFragment extends Fragment {

    private SessionHandler session;
    private ProgressDialog mProgressDialog;

    private static final String KEY_STATUS = "status";
    private static final String KEY_MESSAGE = "message";
    private static final String KEY_EMPTY = "";

    private static final String  KEY_DEPENDANT_NAME = "DependantName";
    private static final String KEY_DEPENDANT_DATE_OF_BIRTH = "DependantBirthDate" ;
    private static final String KEY_DEPENDANT_GENDER = "Gender";
    private static final String KEY_DEPENDANT_DISABLED = "Disabled";
    private static final String KEY_DEPENDANT_RELATIONSHIP = "DependantRelationship";
    private static final String KEY_DEPENDANT_PHONE = "MobileNumber" ;
    private static final String KEY_DEPENDANT_IDS = "DependantsIds" ;

    private static final String KEY_REASONS_REMOVE = "Reason" ;
    private static final String KEY_USERNAME = "Username" ;



private EditText etReason_typed;

    private TextView tvFullName;
    private TextView tvDateOfBirth;
    private TextView tvGender;
    private TextView tvDisabled;
    private TextView tvRelationship;
    private TextView tvPhone;
    private TextView tvIds;
    private TextView textViewRequestNameInREMOVEDEPENDANT;

    private String reasonRemove;
    private String dependantIds;
    private ProgressDialog pDialog;




    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        // Inflate the layout for this fragment
      //  final View view = inflater.inflate(R.layout.fragment_pageremoveetailsinchangeofdetailsfragment, container, false);
        final View view = inflater.inflate(R.layout.layout_deactivated_pages, container, false);

        session = new SessionHandler(getActivity().getApplicationContext());
      /*  User user = session.getUserDetails();

        tvFullName =(TextView) view.findViewById(R.id.TXTview_fullName_REMOVEDEPENDANT);
        tvDateOfBirth =(TextView) view.findViewById(R.id.TXTview_dob_REMOVEDEPENDANT);
        tvGender =(TextView) view.findViewById(R.id.TXTview_gender_REMOVEDEPENDANT);
        tvDisabled =(TextView) view.findViewById(R.id.TXTview_disabled_REMOVEDEPENDANT);
        tvRelationship =(TextView) view.findViewById(R.id.TXTview_relationship_REMOVEDEPENDANT);
        tvPhone =(TextView) view.findViewById(R.id.TXTview_phone_number_REMOVEDEPENDANT);
        tvIds =(TextView) view.findViewById(R.id.TXTview_id_number_REMOVEDEPENDANT);

        textViewRequestNameInREMOVEDEPENDANT = (TextView) view.findViewById(R.id.textViewRequestNameInREMOVEDEPENDANT);


        etReason_typed = (EditText) view.findViewById(R.id.EDITTEXT_ReasonForRequestREMOVEDEPENDANT);

        String dependantName= getArguments().getString(KEY_DEPENDANT_NAME);
        String dependantDob= getArguments().getString(KEY_DEPENDANT_DATE_OF_BIRTH);
        String dependantGender= getArguments().getString(KEY_DEPENDANT_GENDER);
        String dependantDisabled= getArguments().getString(KEY_DEPENDANT_DISABLED);
        String dependantRelationship= getArguments().getString(KEY_DEPENDANT_RELATIONSHIP);
        String dependantPhone= getArguments().getString(KEY_DEPENDANT_PHONE);
        dependantIds= getArguments().getString(KEY_DEPENDANT_IDS);

        textViewRequestNameInREMOVEDEPENDANT.setText(dependantName);
        tvFullName.setText(dependantName);
        tvDateOfBirth.setText(dependantDob);
        tvGender.setText(dependantGender);
        tvDisabled.setText(dependantDisabled);

        tvRelationship.setText(dependantRelationship);
        tvPhone.setText(dependantPhone);
        tvIds.setText(dependantIds);

        //String dependant =getArguments().getString(KEY_DEPENDANT_IDS);

        //ssl security
        HttpsTrustManager.allowMINETSSL();


        Button btnRemoveDependant = view.findViewById(R.id.btnSubmitREMOVEDEPENDANT);
        btnRemoveDependant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                Toast.makeText(getActivity(), dependantIds, Toast.LENGTH_SHORT).show();
                if (validateInputs()) {
                    removeDetails();
                    etReason_typed.getText().clear();

                }
            }
        });
*/

        return view;
    }

    private void removeDetails() {
        displayLoader();
        JSONObject request = new JSONObject();
      /*  try {

            User user = session.getUserDetails()
            //Populate the request parameters
            request.put(KEY_REASONS_REMOVE, reasonRemove);
            request.put(KEY_DEPENDANT_IDS, getArguments().getString(KEY_DEPENDANT_IDS));
            request.put(KEY_USERNAME,user.getUsername());

            // request.put(KEY_PASSWORD, UserCity);

        } catch (JSONException e) {
            e.printStackTrace();
        }*/
        User user = session.getUserDetails();
        reasonRemove = etReason_typed.getText().toString().trim();

        String query;
        try {
            query = URLEncoder.encode( reasonRemove, "utf-8");
            String remove_dependant_url = "https://collaborationkenya.minet.com/minetApi/tsc/RemoveDependant?Username="+user.getUsername()+"&DependantsIds="+dependantIds+"&Reason="+query;
            JsonObjectRequest jsArrayRequest = new JsonObjectRequest
                    (Request.Method.POST, remove_dependant_url, request, new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            pDialog.dismiss();
                            try {
                                //Check if successfully
                                if (response.getInt(KEY_STATUS) == 2) {
                                    Toast.makeText(getActivity().getApplicationContext(),
                                            "Request Successfully sent", Toast.LENGTH_SHORT).show();

                                }else if(response.getInt(KEY_STATUS) == 1){
                                    //Display error message if username is already existing
                                    Toast.makeText(getActivity().getApplicationContext(),
                                            response.getString(KEY_MESSAGE), Toast.LENGTH_SHORT).show();
                                }else{
                                    Toast.makeText(getActivity().getApplicationContext(),
                                            response.getString(KEY_MESSAGE), Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }, new Response.ErrorListener() {

                        @Override
                        public void onErrorResponse(VolleyError error) {
                            pDialog.dismiss();

                            //Display error message whenever an error occurs
                            Toast.makeText(getActivity().getApplicationContext(),
                                    error.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    });

            // Access the RequestQueue through your singleton class.
            MySingleton.getInstance(getActivity()).addToRequestQueue(jsArrayRequest);

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

    }

    /**
     * Display Progress bar while registering
     */
    private void displayLoader() {
        pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage("Changing details.. Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(true);
        pDialog.show();

    }

    /**
     * Validates inputs and shows error if any
     * @return
     */
    private boolean validateInputs() {

        if (KEY_EMPTY.equals(reasonRemove)) {
            etReason_typed.setError("Date of birth cannot be empty");
            etReason_typed.requestFocus();
            return false;
        }


        return true;
    }

}
