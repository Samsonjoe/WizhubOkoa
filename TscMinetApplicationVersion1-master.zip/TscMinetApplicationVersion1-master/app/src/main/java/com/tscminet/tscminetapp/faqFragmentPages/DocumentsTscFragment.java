package com.tscminet.tscminetapp.faqFragmentPages;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.tscminet.tscminetapp.R;
import com.tscminet.tscminetapp.homeFragmentPages.ImagePageViewUploadsinHomeFragment;
import com.tscminet.tscminetapp.homeFragmentPages.PdfUploadinHomeFragment;
import com.tscminet.tscminetapp.loginPage.HttpHandler;
import com.tscminet.tscminetapp.loginPage.SessionHandler;
import com.tscminet.tscminetapp.utils.HttpsTrustManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

public class DocumentsTscFragment extends Fragment {

    private SessionHandler session;
    ArrayList<HashMap<String, String>> uploadList;
    private String TAG = DocumentsTscFragment.class.getSimpleName();
    private ListView lv;

    //JSON Node Names

    private static final String KEY_DOCUMENT = "Document";
    private static final String KEY_RELATED_TO = "RelatedTo";


    private ProgressBar spinner;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        View view = inflater.inflate(R.layout.fragment_tsc_documents_in_faq_fragment, container, false);
        session = new SessionHandler(getActivity().getApplicationContext());
        session = new SessionHandler(getActivity().getApplicationContext());

        uploadList = new ArrayList<>();
        lv = (ListView) view.findViewById(R.id.records_view_document_tsc_files);

        spinner = (ProgressBar) view.findViewById(R.id.progressBarDocumentDownloadsInFaq);
        spinner.setVisibility(View.VISIBLE);

        HttpsTrustManager.allowMINETSSL();

        new GetDownloadDocuments().execute();

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }


    private class GetDownloadDocuments extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Toast.makeText(getActivity(),"Json Data is downloading",Toast.LENGTH_LONG).show();


        }

        @Override
        protected Void doInBackground(Void... arg0) {

            HttpHandler sh = new HttpHandler();

            String url = "https://collaborationkenya.minet.com/MinetAPI/tsc/tscdocuments";
            String jsonStr = sh.makeServiceCall(url);

                /*
                User user = session.getUserUploads();
                String name =user.getUserUploads();
                String jsonStr = name;*/

            Log.e(TAG, "Response from url: " + jsonStr);
            if (uploadList.isEmpty()) {
                if (jsonStr != null) {
                    try {
                        JSONObject jsonObj = new JSONObject(jsonStr);

                        // Getting JSON Array node
                        JSONArray upload_files = jsonObj.getJSONArray("TSCFiles");

                        // looping through All Contacts
                        for (int i = 0; i < upload_files.length(); i++) {

                            JSONObject c = upload_files.getJSONObject(i);


                            // String policy_id = c.getString("");

                            String document = c.getString(KEY_DOCUMENT);



                            // tmp hash map for single upload_file
                            HashMap<String, String> upload_file = new HashMap<>();

                            // adding each child node to HashMap key => value
                            upload_file.put(KEY_DOCUMENT, document);



                            uploadList.add(upload_file);
                        }
                    } catch (final JSONException e) {
                        Log.e(TAG, "Json parsing error: " + e.getMessage());
                        Objects.requireNonNull(getActivity()).runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getActivity().getApplicationContext(),
                                        "Json parsing error: " + e.getMessage(),
                                        Toast.LENGTH_LONG).show();
                            }
                        });

                    }

                } else {
                    Log.e(TAG, "Couldn't get json from server.");
                    Objects.requireNonNull(getActivity()).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getActivity().getApplicationContext(),
                                    "Couldn't get json from server. Check LogCat for possible errors!",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            if (getActivity() != null) {
                // Code goes here.
                ListAdapter adapter = new SimpleAdapter(getActivity(), uploadList,
                        R.layout.list_document_files_in_faq_fragment, new String[]{ KEY_DOCUMENT},
                        new int[]{
                                R.id.document_FragmentFAQ,

                        });


                lv.setAdapter(adapter);

            }

            ListUtils.setDynamicHeight(lv);
            spinner.setVisibility(View.GONE);

            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {


                    String document_type = uploadList.get(i).get(KEY_DOCUMENT);
                    String document_related_to = "TSC IMPORTANT DOCUMENTS";


                    if (document_type.substring(document_type.length() - 3).equalsIgnoreCase("pdf")) {

                        Fragment viewuploadfilesfragment = new PdfUploadinHomeFragment();
                        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.screen_area, viewuploadfilesfragment);
                        fragmentTransaction.addToBackStack(null);
                        fragmentTransaction.commit();

                        //Get the clicked items to pass to PolicyDetailsinRenewPolicyInRenewPolicyFragment class
                        Bundle bundlerenewPolicy = new Bundle();
                        bundlerenewPolicy.putString(KEY_DOCUMENT, document_type);
                        bundlerenewPolicy.putString(KEY_RELATED_TO, document_related_to);


                        viewuploadfilesfragment.setArguments(bundlerenewPolicy);

                    } else {
                        Fragment viewuploadfilesfragment = new ImagePageViewUploadsinHomeFragment();
                        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.screen_area, viewuploadfilesfragment);
                        fragmentTransaction.addToBackStack(null);
                        fragmentTransaction.commit();

                        //Get the clicked items to pass to PolicyDetailsinRenewPolicyInRenewPolicyFragment class
                        Bundle bundlerenewPolicy = new Bundle();
                        bundlerenewPolicy.putString(KEY_DOCUMENT, document_type);
                        bundlerenewPolicy.putString(KEY_RELATED_TO, document_related_to);


                        viewuploadfilesfragment.setArguments(bundlerenewPolicy);

                        // Toast.makeText(getActivity(),"Pic"+i+l+"Selected",Toast.LENGTH_SHORT).show();
                    }

                }
            });


        }
    }


    public static class ListUtils {
        public static void setDynamicHeight(ListView mListView) {
            ListAdapter mListAdapter = mListView.getAdapter();
            if (mListAdapter == null) {
                // when adapter is null
                return;
            }
            int height = 0;
            int desiredWidth = View.MeasureSpec.makeMeasureSpec(mListView.getWidth(), View.MeasureSpec.UNSPECIFIED);
            for (int i = 0; i < mListAdapter.getCount(); i++) {
                View listItem = mListAdapter.getView(i, null, mListView);
                listItem.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
                height += listItem.getMeasuredHeight();
            }
            ViewGroup.LayoutParams params = mListView.getLayoutParams();
            params.height = height + (mListView.getDividerHeight() * (mListAdapter.getCount() - 1));
            mListView.setLayoutParams(params);
            mListView.requestLayout();
        }
    }
}