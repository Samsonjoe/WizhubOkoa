package com.tscminet.tscminetapp.homeFragmentPages;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.tscminet.tscminetapp.R;
import com.tscminet.tscminetapp.loginPage.SessionHandler;
import com.tscminet.tscminetapp.loginPage.User;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class UploadFilesInHomeFragment extends androidx.fragment.app.Fragment {

    private String TAG = UploadFilesInHomeFragment.class.getSimpleName();
    private ListView lv;

    //JSON Node Names
    private static final String  KEY_DEPENDANT_NAME = "DependantName";
    private static final String KEY_DEPENDANT_RELATIONSHIP = "DependantRelationship";
    private static final String KEY_DEPENDANT_STATUS = "DependantStatus";
    private static final String KEY_DATE_ADDED = "DependantDateAdded" ;
    private static final String KEY_DEPENDANT_DATE_OF_BIRTH ="DependantBirthDate";
    private static final String KEY_DEPENDANT_ID = "DependantsIds" ;
    private static final String KEY_DEPENDNANT_DISABILITY = "Disabled";


    private SessionHandler session;
    ArrayList<HashMap<String, String>> dependantList;
    private ProgressBar spinner;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        View view = inflater.inflate(R.layout.fragment_upload_files_in_home_fragment,container,false);
        session = new SessionHandler(getActivity().getApplicationContext());

        dependantList = new ArrayList<>();
        lv = (ListView) view.findViewById(R.id.records_view_fragment_dependants_in_home);

        spinner =(ProgressBar)view.findViewById(R.id.progressBarDependantsInHome);
        spinner.setVisibility(View.VISIBLE);

        new GetDependants().execute();

        return view;
    }

    private class GetDependants extends AsyncTask<Void, Void, Void> {


        @Override
        protected Void doInBackground(Void... arg0) {

            User user = session.getUserDependants();
            String name =user.getUserDependants();
            String jsonStr = name;

            Log.e(TAG, "Response from url: " + jsonStr);
            if(dependantList.isEmpty()) {
                if (jsonStr != null) {
                    try {
                        JSONObject jsonObj = new JSONObject(jsonStr);

                        // Getting JSON Array node
                        JSONArray dependants = jsonObj.getJSONArray("Dependants");

                        // looping through All Contacts
                        for (int i = 0; i < dependants.length(); i++) {

                            JSONObject c = dependants.getJSONObject(i);

                                // String policy_id = c.getString("");
                                String dependant_name = c.getString(KEY_DEPENDANT_NAME);
                                String relationship = c.getString(KEY_DEPENDANT_RELATIONSHIP);
                                String status = c.getString(KEY_DEPENDANT_STATUS);
                                String date_added = c.getString(KEY_DATE_ADDED);
                                String dependant_date_of_birth = c.getString(KEY_DEPENDANT_DATE_OF_BIRTH);
                                String dependant_id = c.getString(KEY_DEPENDANT_ID);
                                String dependant_disability = c.getString(KEY_DEPENDNANT_DISABILITY);




                                // tmp hash map for single dependant
                                HashMap<String, String> dependant = new HashMap<>();

                                // adding each child node to HashMap key => value
                                dependant.put(KEY_DEPENDANT_NAME, dependant_name);
                                dependant.put(KEY_DEPENDANT_RELATIONSHIP, relationship);
                                dependant.put(KEY_DEPENDANT_STATUS, status);
                                dependant.put(KEY_DATE_ADDED, date_added);
                                dependant.put(KEY_DEPENDANT_DATE_OF_BIRTH,dependant_date_of_birth);
                                dependant.put(KEY_DEPENDANT_ID, dependant_id);
                                dependant.put(KEY_DEPENDNANT_DISABILITY,dependant_disability);



                            dependantList.add(dependant);

                        }
                    } catch (final JSONException e) {
                        Log.e(TAG, "Json parsing error: " + e.getMessage());
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getActivity().getApplicationContext(),
                                        "Json parsing error: " + e.getMessage(),
                                        Toast.LENGTH_LONG).show();
                            }
                        });

                    }

                } else {
                    Log.e(TAG, "Couldn't get json from server.");
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getActivity().getApplicationContext(),
                                    "Couldn't get json from server. Check LogCat for possible errors!",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            if (getActivity() != null) {
               // Code goes here.
                ListAdapter adapter = new SimpleAdapter(getActivity(), dependantList, R.layout.list_item_dependants_in_home_fragment, new String[]{ KEY_DEPENDANT_NAME, KEY_DEPENDANT_RELATIONSHIP, KEY_DEPENDANT_STATUS},
                        new int[]{ R.id.dependant_name_FRAGDEPENDANTHOMEFRAGMENT,
                                R.id.dependant_relationship_FRAGDEPENDANTHOMEFRAGMENT,R.id.dependant_status_FRAGDEPENDANTHOMEFRAGMENT});


                lv.setAdapter(adapter);


            }

            ListUtils.setDynamicHeight(lv);
            spinner.setVisibility(View.GONE);


            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {


                    String dependant_name = dependantList.get(i).get(KEY_DEPENDANT_NAME);
                    String dependant_id = dependantList.get(i).get(KEY_DEPENDANT_ID);
                    String dependant_disabiliy = dependantList.get(i).get(KEY_DEPENDNANT_DISABILITY);
                    String dependant_relationship = dependantList.get(i).get(KEY_DEPENDANT_RELATIONSHIP);
                    String dependant_date_of_birth = dependantList.get(i).get(KEY_DEPENDANT_DATE_OF_BIRTH);



                    Fragment renewPolicyfragment = new PageUploadFilesInDependantInHomeFragment();
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.screen_area, renewPolicyfragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();

                    //Get the clicked items to pass to PolicyDetailsinRenewPolicyInRenewPolicyFragment class
                    Bundle bundlerenewPolicy = new Bundle();
                    bundlerenewPolicy.putString(KEY_DEPENDANT_NAME, dependant_name);
                    bundlerenewPolicy.putString(KEY_DEPENDANT_ID, dependant_id);
                    bundlerenewPolicy.putString(KEY_DEPENDNANT_DISABILITY,dependant_disabiliy);
                    bundlerenewPolicy.putString(KEY_DEPENDANT_RELATIONSHIP,dependant_relationship);
                    bundlerenewPolicy.putString(KEY_DEPENDANT_DATE_OF_BIRTH,dependant_date_of_birth);


                    renewPolicyfragment.setArguments(bundlerenewPolicy);

                   // Toast.makeText(getActivity(),"Pic"+i+l+"Selected",Toast.LENGTH_SHORT).show();

                }
            });

        }
    }


    public static class ListUtils {
        public static void setDynamicHeight(ListView mListView) {
            ListAdapter mListAdapter = mListView.getAdapter();
            if (mListAdapter == null) {
                // when adapter is null
                return;
            }
            int height = 0;
            int desiredWidth = View.MeasureSpec.makeMeasureSpec(mListView.getWidth(), View.MeasureSpec.UNSPECIFIED);
            for (int i = 0; i < mListAdapter.getCount(); i++) {
                View listItem = mListAdapter.getView(i, null, mListView);
                listItem.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
                height += listItem.getMeasuredHeight();
            }
            ViewGroup.LayoutParams params = mListView.getLayoutParams();
            params.height = height + (mListView.getDividerHeight() * (mListAdapter.getCount() - 1));
            mListView.setLayoutParams(params);
            mListView.requestLayout();
        }
    }
}

