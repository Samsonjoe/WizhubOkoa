package com.tscminet.tscminetapp.fragments;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.tscminet.tscminetapp.R;
import com.tscminet.tscminetapp.loginPage.MySingleton;
import com.tscminet.tscminetapp.loginPage.SessionHandler;
import com.tscminet.tscminetapp.loginPage.User;
import com.tscminet.tscminetapp.utils.HttpsTrustManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Objects;

public class ChronicDiseasesEnrollmentFragment extends androidx.fragment.app.Fragment {

    public ChronicDiseasesEnrollmentFragment(){
        // Required empty public constructor
    }

    private static final String KEY_STATUS = "status";
    private static final String KEY_MESSAGE = "message";

    private static final String KEY_FULL_NAME_CHRONIC = "Fullname";
    private static final String KEY_PHONE_CHRONIC = "PhoneNo";
    private static final String KEY_EMAIL_CHRONIC = "Email";
    private static final String KEY_TSC_NUMBER_CHRONIC = "TSCNo";
    private static final String KEY_COUNTY_CHRONIC = "County";
    private static final String KEY_STATUS_CHRONIC= "Status";
    private static final String KEY_CONDITION_CHRONIC= "Condition";
    private static final String KEY_OTHER_CONDITION_CHRONIC = "Other";
    private static final String KEY_HOSPITAL_CHRONIC = "Hospital";

    private static final String KEY_EMPTY = "";
    private static final String KEY_SPINNER_COUNTY = "County";
    private static final String KEY_SPINNER_STATUS = "Status";
    private static final String KEY_SPINNER_CONDITION = "Condition";
    private static final String KEY_SPINNER_CONDITION_OTHER = "OTHERS";

    private EditText etFullName;
    private EditText etEmail;
    private EditText etOtherCondition;
    private EditText etHospital;

    private Spinner spinnerCounty;
    private Spinner spinnerStatus;
    private Spinner spinnerCondition;


    private String fullName;
    private String phone;
    private String email;
    private String tscNo;
    private String county;
    private String status;
    private String condition;
    private String otherCondition;
    private String hospital;

    private Button ButtonSubmitChronic;
    private CheckBox checkboxTermsAndCondition;


    private ProgressDialog pDialog;
    private SessionHandler session;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_chronic_diseases_enrollment, container, false);

        session = new SessionHandler(getActivity().getApplicationContext());


        etFullName = view.findViewById(R.id.etFullNameChronic);
        etEmail = view.findViewById(R.id.etEmailChronic);
        etOtherCondition = view.findViewById(R.id.etOtherConditionChronic);
        etHospital = view.findViewById(R.id.etHospitalChronic);

        spinnerCounty = view.findViewById(R.id.spinnerCountyChronic);
        spinnerStatus = view.findViewById(R.id.spinnerStatusChronic);
        spinnerCondition = view.findViewById(R.id.spinnerConditionChronic);

        ButtonSubmitChronic = view.findViewById(R.id.ButtonSubmitChronic);

        checkboxTermsAndCondition = view.findViewById(R.id.checkboxTermsAndCondition);
        checkboxTermsAndCondition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Is the view now checked?
                boolean checked = ((CheckBox) view).isChecked();
                // Check which checkbox was clicked
                if (view.getId() == R.id.checkboxTermsAndCondition) {
                    if (checked) {
                        // Do your coding
                        Toast.makeText(getActivity(), "ACCEPTED", Toast.LENGTH_SHORT).show();
                        ButtonSubmitChronic.setVisibility(View.VISIBLE);
                    } else {
                        // Do your coding
                        Toast.makeText(getActivity(), "KINDLY ACCEPT TERMS AND CONDITIONS", Toast.LENGTH_SHORT).show();
                        ButtonSubmitChronic.setVisibility(View.GONE);
                    }
                    // Perform your logic
                }
            }
        });

        TextView termsNconditions = view.findViewById(R.id.termsNconditions);
        termsNconditions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                new AlertDialog.Builder(getActivity())
                        .setTitle("Terms & Conditions")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                checkboxTermsAndCondition.setChecked(true);
                                ButtonSubmitChronic.setVisibility(View.VISIBLE);
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(getActivity(), "KINDLY ACCEPT TERMS AND CONDITIONS", Toast.LENGTH_SHORT).show();
                                checkboxTermsAndCondition.setChecked(false);
                                ButtonSubmitChronic.setVisibility(View.GONE);
                            }
                        })
                        .setMessage("I hereby authorize Minet Kenya Insurance Brokers who are my/or my employers medical scheme administrators to enrol me into the Minet Chronic Disease Management Program. With this enrolment I fully understand as follows:\n" +
                                "\n" +
                                "1. The doctors and clinical team will periodically contact me on email or telephone for an update and to offer any assistance I may need during the course of my treatment.\n" +
                                "2. The doctors/hospitals that I am or will be attending to me will provide Minet Kenya with detailed medical information and other relevant information as and when need may arise.\n" +
                                "3. My condition may be subject to disease management interventions and protocols as well as periodic review of my medical records from attending doctors.\n" +
                                "4. I may discontinue my enrolment from this program if I cease to be an employee of the company.\n" +
                                "5. I will be supported through health coaching and other tools in order to make better health choices.")
                        .show();

            }
        });

        //ssl security
        HttpsTrustManager.allowMINETSSL();
        User user = session.getUserDetails();

        ButtonSubmitChronic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Retrieve the data entered in the edit texts
                fullName = etFullName.getText().toString().trim();
                phone = user.getUserPhoneNumber();
                email = etEmail.getText().toString().trim();
                tscNo =user.getUsername();
                otherCondition = etOtherCondition.getText().toString().trim();
                hospital = etHospital.getText().toString().trim();

                county = spinnerCounty.getSelectedItem().toString().trim();
                status = spinnerStatus.getSelectedItem().toString().trim();
                condition = spinnerCondition.getSelectedItem().toString().trim();
                if (validateInputs()) {
                    Chronic_enrolment();
                }

            }
        });


        return view;
    }

    //Terms and conditions check box
    public void onCheckBoxClick(View view) {

        // Is the view now checked?
        boolean checked = ((CheckBox) view).isChecked();
        // Check which checkbox was clicked
        if (view.getId() == R.id.checkboxTermsAndCondition) {
            if (checked) {
                // Do your coding
                Toast.makeText(getActivity(), "ACCEPTED", Toast.LENGTH_SHORT).show();
                ButtonSubmitChronic.setVisibility(View.VISIBLE);
            } else {
                // Do your coding
                Toast.makeText(getActivity(), "KINDLY ACCEPT TERMS AND CONDITIONS", Toast.LENGTH_SHORT).show();
                ButtonSubmitChronic.setVisibility(View.GONE);
            }
            // Perform your logic
        }
    }


    /**
     * Display Progress bar while Logging in
     */

    private void displayLoader() {
        pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage("submiting details.. Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();

    }
    /**
     * Launch Dashboard Activity on Successful Login
     */
    private void loadDashboard() {

        //Clear EditText
        etFullName.getText().clear();
        etEmail.getText().clear();
        etOtherCondition.getText().clear();
        etHospital.getText().clear();
    }

    private void Chronic_enrolment() {
            displayLoader();
            JSONObject request = new JSONObject();
            try {

                //Populate the request parameters
                request.put(KEY_FULL_NAME_CHRONIC, fullName);
                request.put(KEY_PHONE_CHRONIC, phone);
                request.put(KEY_EMAIL_CHRONIC, email);
                request.put(KEY_TSC_NUMBER_CHRONIC, tscNo);
                request.put(KEY_COUNTY_CHRONIC, county);
                request.put(KEY_STATUS_CHRONIC, status);
                request.put(KEY_CONDITION_CHRONIC, condition);
                request.put(KEY_OTHER_CONDITION_CHRONIC, otherCondition);
                request.put(KEY_HOSPITAL_CHRONIC, hospital);



            } catch (JSONException e) {
                e.printStackTrace();
            }
        String chronic_enrolment_URL = "https://collaborationkenya.minet.com/MinetAPI/tsc/cde";
        JsonObjectRequest jsArrayRequest = new JsonObjectRequest
                    (Request.Method.POST, chronic_enrolment_URL, request, new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            pDialog.dismiss();
                            try {
                                //Check if user got logged in successfully

                                if (response.getInt(KEY_STATUS) == 0) {

                                    Toast.makeText(Objects.requireNonNull(getActivity()).getApplicationContext(),
                                            "Chronic Submission successfully", Toast.LENGTH_SHORT).show();

                                    loadDashboard();

                                }else{
                                    Toast.makeText(Objects.requireNonNull(getActivity()).getApplicationContext(),
                                            response.getString(KEY_MESSAGE), Toast.LENGTH_SHORT).show();

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }, new Response.ErrorListener() {

                        @Override
                        public void onErrorResponse(VolleyError error) {
                            pDialog.dismiss();

                            //Display error message whenever an error occurs
                            Toast.makeText(Objects.requireNonNull(getActivity()).getApplicationContext(),
                                    error.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    });


            // Access the RequestQueue through your singleton class.
            MySingleton.getInstance(getActivity()).addToRequestQueue(jsArrayRequest);
    }


    /**
     * Validates inputs and shows error if any
     * @return
     */
    private boolean validateInputs() {


        if (KEY_EMPTY.equals(fullName)) {
            etFullName.setError("Full Name cannot be empty");
            etFullName.requestFocus();
            return false;

        }


        if (KEY_EMPTY.equals(email)) {
            etEmail.setError("Email address cannot be empty");
            etEmail.requestFocus();
            return false;
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("enter a valid email address");
            etEmail.requestFocus();
            return false;
        }

        if (KEY_SPINNER_COUNTY.equals(county)) {
            Toast.makeText(getActivity(), "Kindly Select a county", Toast.LENGTH_SHORT).show();
            spinnerCounty.requestFocus();
            return false;
        }
        if (KEY_SPINNER_STATUS.equals(status)) {
            Toast.makeText(getActivity(), "Kindly Select a status", Toast.LENGTH_SHORT).show();
            spinnerStatus.requestFocus();
            return false;
        }
        if (KEY_SPINNER_CONDITION.equals(condition)) {
            Toast.makeText(getActivity(), "Kindly Select a condition", Toast.LENGTH_SHORT).show();
            spinnerCondition.requestFocus();
            return false;
        }

        if (KEY_SPINNER_CONDITION_OTHER.equals(condition)) {
           etOtherCondition.setError("Kindly Specify Others");
           etOtherCondition.requestFocus();
            return false;
        }

        if (KEY_EMPTY.equals(hospital)) {
            etHospital.setError("Hospital cannot be empty");
            etHospital.requestFocus();
            return false;
        }

        return true;
    }
}
