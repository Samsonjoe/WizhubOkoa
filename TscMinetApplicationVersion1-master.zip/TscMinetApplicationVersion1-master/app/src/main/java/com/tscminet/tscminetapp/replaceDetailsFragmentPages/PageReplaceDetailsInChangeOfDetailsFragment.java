package com.tscminet.tscminetapp.replaceDetailsFragmentPages;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.tscminet.tscminetapp.R;
import com.tscminet.tscminetapp.loginPage.SessionHandler;
import com.tscminet.tscminetapp.loginPage.User;


public class PageReplaceDetailsInChangeOfDetailsFragment extends Fragment {

    private SessionHandler session;

    private static final String  KEY_DEPENDANT_NAME = "DependantName";
    private static final String KEY_DEPENDANT_DATE_OF_BIRTH = "DependantBirthDate" ;
    private static final String KEY_DEPENDANT_GENDER = "Gender";
    private static final String KEY_DEPENDANT_DISABLED = "Disabled";
    private static final String KEY_DEPENDANT_RELATIONSHIP = "DependantRelationship";
    private static final String KEY_DEPENDANT_PHONE = "MobileNumber" ;
    private static final String KEY_DEPENDANT_IDS = "DependantsIds" ;

    private static final String KEY_FIRST_NAME = "Fname";
    private static final String KEY_SECOND_NAME = "Sname";
    private static final String KEY_LAST_NAME = "Lname";


    private EditText etFName;
    private EditText etSName;
    private EditText etLName;
    private EditText etPhone;
    private EditText etIds;

    private EditText tvDateOfBirth;
    private TextView textViewRequestNameInREPLACEDEPENDANT;

    private Spinner spinnerGender;
    private Spinner spinnerDisabled;
    private Spinner spinnerRelationship;
    private Spinner spinnerReplaceSelectFileType;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        //final View view = inflater.inflate(R.layout.fragment_pagereplacedetailsinchangeofdetailsfragment, container, false);

        final View view = inflater.inflate(R.layout.layout_deactivated_pages, container, false);

        session = new SessionHandler(getActivity().getApplicationContext());
     /*   User user = session.getUserDetails();

        etFName = (EditText) view.findViewById(R.id.etDependantFirstNameREPLACE);
        etSName = (EditText) view.findViewById(R.id.etDependantSecondNameREPLACE);
        etLName = (EditText) view.findViewById(R.id.etDependantLastNameREPLACE);
        etPhone = (EditText) view.findViewById(R.id.etPhoneREPLACE);
        etIds = (EditText) view.findViewById(R.id.etUserIDREPLACE);


        tvDateOfBirth = (EditText) view.findViewById(R.id.etDependantDOBREPLACE);

        textViewRequestNameInREPLACEDEPENDANT = (TextView) view.findViewById(R.id.textViewRequestNameInREPLACEDEPENDANT);

       spinnerGender = (Spinner) view.findViewById(R.id.spinnerGenderReplace);
        spinnerDisabled = (Spinner) view.findViewById(R.id.spinnerDisabilityReplace);
        spinnerRelationship = (Spinner) view.findViewById(R.id.spinnerRelationshipReplace);
        spinnerReplaceSelectFileType =(Spinner) view.findViewById(R.id.spinnerReplaceSelectFileType);

        String dependantName= getArguments().getString(KEY_DEPENDANT_NAME);
        String dependantFName= getArguments().getString(KEY_FIRST_NAME);
        String dependantSName= getArguments().getString(KEY_SECOND_NAME);
        String dependantLName= getArguments().getString(KEY_LAST_NAME);

        String dependantDob= getArguments().getString(KEY_DEPENDANT_DATE_OF_BIRTH);

        String dependantGender= getArguments().getString(KEY_DEPENDANT_GENDER);
        String dependantDisabled= getArguments().getString(KEY_DEPENDANT_DISABLED);
        String dependantRelationship= getArguments().getString(KEY_DEPENDANT_RELATIONSHIP);

        String dependantPhone= getArguments().getString(KEY_DEPENDANT_PHONE);
        String dependantIds= getArguments().getString(KEY_DEPENDANT_IDS);

        textViewRequestNameInREPLACEDEPENDANT.setText(dependantName);
        etFName.setText(dependantFName);
        etSName.setText(dependantSName);
        etLName.setText(dependantLName);
        etPhone.setText(dependantPhone);
        etIds.setText(dependantIds);
        tvDateOfBirth.setText(dependantDob);

        spinnerGender.setSelection(getIndexByString(spinnerGender, dependantGender));
        spinnerDisabled.setSelection(getIndexByString(spinnerDisabled, dependantDisabled));
        spinnerRelationship.setSelection(getIndexByString(spinnerRelationship, dependantRelationship));


*/

        return view;
    }

    /**
     * Populating spinner with a string value gotten from database
     *
     * @return
     */

    private int getIndexByString(Spinner spinner, String string) {
        int index = 0;

        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(string)) {
                index = i;
                break;
            }
        }
        return index;
    }



}
