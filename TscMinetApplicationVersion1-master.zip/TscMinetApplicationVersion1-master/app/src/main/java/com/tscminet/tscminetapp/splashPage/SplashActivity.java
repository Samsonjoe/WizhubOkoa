package com.tscminet.tscminetapp.splashPage;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.tscminet.tscminetapp.MainActivity;
import com.tscminet.tscminetapp.R;
import com.tscminet.tscminetapp.onBoarding.ImageBackgroundExampleActivity;


public class SplashActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        Thread splash = new Thread(){
            @Override
            public void run() {
                try {
                    sleep(1000);
                    Intent go = new Intent(SplashActivity.this, ImageBackgroundExampleActivity.class);
                    startActivity(go);
                    finish();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        splash.start();
    }
}
