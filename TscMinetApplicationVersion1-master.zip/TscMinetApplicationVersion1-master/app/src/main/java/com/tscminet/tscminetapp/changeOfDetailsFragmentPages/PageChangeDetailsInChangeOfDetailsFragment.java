package com.tscminet.tscminetapp.changeOfDetailsFragmentPages;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.tscminet.tscminetapp.R;
import com.tscminet.tscminetapp.loginPage.MySingleton;
import com.tscminet.tscminetapp.loginPage.SessionHandler;
import com.tscminet.tscminetapp.loginPage.User;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;


public class PageChangeDetailsInChangeOfDetailsFragment extends Fragment {

    private SessionHandler session;
    private ProgressDialog mProgressDialog;

    private static final String KEY_STATUS = "status";
    private static final String KEY_MESSAGE = "message";
    private static final String KEY_EMPTY = "";

    private static final String  KEY_DEPENDANT_NAME = "DependantName";
    private static final String KEY_DEPENDANT_RELATIONSHIP = "DependantRelationship";
    private static final String KEY_DEPENDANT_GENDER = "Gender";
    private static final String KEY_DATE_OF_BIRTH = "DependantBirthDate" ;
    private static final String KEY_DEPENDANT_DISABILITY = "Disabled";
    private static final String KEY_DEPENDANT_PHONE= "MobileNumber";
    private static final String KEY_DEPENDANT_ID = "DependantsIds" ;
    private static final String KEY_DEPENDANT_ID_NUMBER = "IdNumber" ;
    private static final String KEY_USERNAME ="Username";


    private static final String KEY_LIST_ITEMS_ = "List" ;

    private static final String KEY_SPINNER_DISABILITY = "Disabled";
    private static final String KEY_SPINNER_GENDER= "Gender";
    private static final String KEY_SPINNER_RELATIONSHIP= "Relationship" ;

    private TextView tvFullName;

    private TextView tvDateOfBirth;
    private EditText etPhone;
    private EditText etDependantID;
    private EditText etListItemsChanged;

    private Spinner spinnerGender;
    private Spinner spinnerDiabled;
    private Spinner spinnerRelationship;

    private String dob_changed;
    private String phone_changed;
    private String id_changed;
    private String gender_changed;
    private String disability_changed;
    private String relationship_changed;
    private String list_changed;

    private ProgressDialog pDialog;
    final Calendar cldr = Calendar.getInstance();
    private DatePickerDialog picker;


    private String change_details_url = "https://collaborationkenya.minet.com/MinetAPI/tsc/ChangeDetails";


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        // Inflate the layout for this fragment
       // final View view = inflater.inflate(R.layout.fragment_pagechangedetailsinchangeofdetailsfragment, container, false);
        final View view = inflater.inflate(R.layout.layout_deactivated_pages, container, false);

        session = new SessionHandler(getActivity().getApplicationContext());

        /*tvFullName = (TextView) view.findViewById(R.id.TXTview_fullName_change_details);

        tvDateOfBirth = (TextView) view.findViewById(R.id.tvDependantDOBChangeDetails);
        etPhone = (EditText) view.findViewById(R.id.etPhoneChangeDetails);
        etDependantID = (EditText) view.findViewById(R.id.etDependantIDChangeDetails);
        etListItemsChanged = (EditText) view.findViewById(R.id.etListItemChangeDetails);

        spinnerGender = (Spinner) view.findViewById(R.id.spinnerGenderChangeDetails);
        spinnerDiabled = (Spinner) view.findViewById(R.id.spinnerDisabilityChangeDetails);
        spinnerRelationship = (Spinner) view.findViewById(R.id.spinnerRelationshipChangeDetails);

        String dependantName= getArguments().getString(KEY_DEPENDANT_NAME);
        String dependantDob= getArguments().getString(KEY_DATE_OF_BIRTH);
        String dependantGender= getArguments().getString(KEY_DEPENDANT_GENDER);
        String dependantDisabled= getArguments().getString(KEY_DEPENDANT_DISABILITY);
        String dependantRelationship= getArguments().getString(KEY_DEPENDANT_RELATIONSHIP);
        String dependantPhone= getArguments().getString(KEY_DEPENDANT_PHONE);
        String dependantIds= getArguments().getString(KEY_DEPENDANT_ID_NUMBER);




        tvFullName.setText(dependantName);
        tvDateOfBirth.setText(dependantDob);
        etPhone.setText(dependantPhone);
        etDependantID.setText(dependantIds);

        spinnerGender.setSelection(getIndexByString(spinnerGender, dependantGender));
        spinnerDiabled.setSelection(getIndexByString(spinnerDiabled, dependantDisabled));
        spinnerRelationship.setSelection(getIndexByString(spinnerRelationship, dependantRelationship));

        tvDateOfBirth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);
                // date picker dialog
                picker = new DatePickerDialog(getActivity(),R.style.MySpinnerDatePickerStyle,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                cldr.set(year, monthOfYear, dayOfMonth);

                                SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

                                String dateString = dateFormat.format(cldr.getTime());

                                //eText.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                                tvDateOfBirth.setText(dateString);
                            }
                        }, year, month, day);

                // Set dialog Title
                //picker.setTitle("Please select date of Birth");
                // Popup the dialog.
                picker.show();
            }
        });

        Button btnChangeDetails = view.findViewById(R.id.buttonSendChangeOfDetails);
        btnChangeDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                dob_changed = tvDateOfBirth.getText().toString().trim();
                phone_changed = etPhone.getText().toString().trim();
                id_changed = etDependantID.getText().toString().trim();
                gender_changed = spinnerGender.getSelectedItem().toString().trim();
                disability_changed = spinnerDiabled.getSelectedItem().toString().trim();
                relationship_changed= spinnerRelationship.getSelectedItem().toString().trim();
                list_changed= etListItemsChanged.getText().toString().trim();

                if (validateInputs()) {
                    changeOfDetails();
                    etListItemsChanged.getText().clear();

                }
            }
        });*/

        return view;
    }

    private void changeOfDetails() {
        displayLoader();
        JSONObject request = new JSONObject();
        try {

            User user = session.getUserDetails();

            //Populate the request parameters
            request.put(KEY_DATE_OF_BIRTH, dob_changed);
            request.put(KEY_DEPENDANT_GENDER, gender_changed);
            request.put(KEY_DEPENDANT_DISABILITY, disability_changed);
            request.put(KEY_DEPENDANT_RELATIONSHIP, relationship_changed);
            request.put(KEY_DEPENDANT_PHONE, phone_changed);
            request.put(KEY_DEPENDANT_ID, getArguments().getString(KEY_DEPENDANT_ID));
            request.put(KEY_LIST_ITEMS_, list_changed);
            request.put(KEY_DEPENDANT_ID_NUMBER,id_changed);
            request.put(KEY_USERNAME, user.getUsername());

            // request.put(KEY_PASSWORD, UserCity);



        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest jsArrayRequest = new JsonObjectRequest
                (Request.Method.POST, change_details_url, request, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        pDialog.dismiss();
                        try {
                            //Check if user got registered successfully
                            if (response.getInt(KEY_STATUS) == 0) {
                                //Set the user session
                                   /* session.loginUser(username,fullName,UserEmail, UserIdNumber,
                                             UserKraPin,  UserDateofBirth,  UserGender,  UserNationality,  UserAddress);   */
                                Toast.makeText(getActivity().getApplicationContext(),
                                     "Request Successfully sent", Toast.LENGTH_SHORT).show();

                                //sendMail();
                            }else if(response.getInt(KEY_STATUS) == 1){
                                //Display error message if username is already existsing
                                Toast.makeText(getActivity().getApplicationContext(),
                                        response.getString(KEY_MESSAGE), Toast.LENGTH_SHORT).show();

                            }else{
                                Toast.makeText(getActivity().getApplicationContext(),
                                        response.getString(KEY_MESSAGE), Toast.LENGTH_SHORT).show();

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pDialog.dismiss();

                        //Display error message whenever an error occurs
                        Toast.makeText(getActivity().getApplicationContext(),
                                error.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });

        // Access the RequestQueue through your singleton class.
        MySingleton.getInstance(getActivity()).addToRequestQueue(jsArrayRequest);
    }



/**
     * Validates inputs and shows error if any
     * @return
     */
    private boolean validateInputs() {

        if (KEY_EMPTY.equals(dob_changed)) {
            tvDateOfBirth.setError("Date of birth cannot be empty");
            tvDateOfBirth.requestFocus();
            return false;

        }
        if (KEY_EMPTY.equals(phone_changed)) {
            etPhone.setError("Phone number cannot be empty");
            etPhone.requestFocus();
            return false;
        }


        if (KEY_EMPTY.equals(list_changed)) {
            etListItemsChanged.setError("List of Items changed cannot be empty cannot be empty");
            etListItemsChanged.requestFocus();
            return false;
        }

        if (KEY_SPINNER_GENDER.equals(gender_changed)) {
            Toast.makeText(getActivity(), "Kindly Select gender", Toast.LENGTH_SHORT).show();
            spinnerGender.requestFocus();
            return false;
        }

        if (KEY_SPINNER_DISABILITY.equals(disability_changed)) {
            Toast.makeText(getActivity(), "Kindly Select yes or no for disabled", Toast.LENGTH_SHORT).show();
            spinnerDiabled.requestFocus();
            return false;
        }

        if (KEY_SPINNER_RELATIONSHIP.equals(relationship_changed)) {
            Toast.makeText(getActivity(), "Kindly Select the relationship", Toast.LENGTH_SHORT).show();
            spinnerRelationship.requestFocus();
            return false;
        }


        return true;
    }
    /**
     * Display Progress bar while registering
     */
    private void displayLoader() {
        pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage("Changing details.. Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(true);
        pDialog.show();

    }

    /**
     * Populating spinner with a string value gotten from database
     *
     * @return
     */

    private int getIndexByString(Spinner spinner, String string) {
        int index = 0;

        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(string)) {
                index = i;
                break;
            }
        }
        return index;
    }


}
