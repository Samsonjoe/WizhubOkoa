package com.tscminet.tscminetapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.tscminet.tscminetapp.loginPage.MySingleton;
import com.tscminet.tscminetapp.loginPage.VerificationCodeActivity;
import com.tscminet.tscminetapp.utils.HttpsTrustManager;

import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

// (4) Setting up an interface for the MainActivity
interface MainActivityDataTaskNotification {
    void notifyMainActivity(String connStatus, String connInstruction);
}

public class MainActivity extends AppCompatActivity {

    private static final String KEY_STATUS = "status";
    private static final String KEY_MESSAGE = "message";

    private static final String KEY_USERNAME = "username";

    private static final String KEY_EMPTY = "";
    private EditText etUsername;
    private String username;
    public static Button next;
    public static Button CheckTsc;
    private String login_url = "https://collaborationkenya.minet.com/MinetAPI/tsc/RequestOTP";


    private ProgressDialog pDialog;
    boolean doubleBackToExitPressedOnce = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        next = findViewById(R.id.ButtonProceedTscNumber);
        CheckTsc =  findViewById(R.id.ButtonCheckTscNumber);
        etUsername = findViewById(R.id.etLoginUsername);

       // getCurrentVersion();
        //ssl security
        HttpsTrustManager.allowMINETSSL();

        CheckTsc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Retrieve the data entered in the edit texts
                username = etUsername.getText().toString().toLowerCase().trim();
                if (validateInputs()) {
                    requestDataCallback();
                    login();

                    next.setVisibility(View.VISIBLE);
                    // Toast.makeText(getApplicationContext(),"YEEEEEEEEEEEEEEEEEEEEEEESSSSSSSSSSSS", Toast.LENGTH_SHORT).show();
                }

            }
        });


        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(validateInputs()) {
                    loadDashboard();

                }
            }
        });
    }

    @Override
    public void onBackPressed(){

        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);


    }


    /**
     * Launch Dashboard Activity on Successful Login
     */
    private void loadDashboard() {
        Intent i = new Intent(getApplicationContext(), VerificationCodeActivity.class);
        i.putExtra("USERNAME_TO_VERIFICATION_PAGE", username);
        startActivity(i);
        finish();

    }

    /**
     * Display Progress bar while Logging in
     */

    private void displayLoader() {
        pDialog = new ProgressDialog(MainActivity.this);
        pDialog.setMessage("Verification being sent.. Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();

    }

    private void login() {
        displayLoader();
        JSONObject request = new JSONObject();

        try {
            //Populate the request parameters
            request.put(KEY_USERNAME, username);
           // request.put(KEY_PASSWORD, password);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest jsArrayRequest = new JsonObjectRequest
                (Request.Method.POST, login_url, request, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        pDialog.dismiss();

                        try {
                            //Check if user got logged in successfully
                            if (response.getInt(KEY_STATUS) == 0) {

                                Toast.makeText(getApplicationContext(),
                                        "Verification sent successfully", Toast.LENGTH_SHORT).show();

                                loadDashboard();

                            }else{
                                Toast.makeText(getApplicationContext(),
                                        response.getString(KEY_MESSAGE), Toast.LENGTH_SHORT).show();

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pDialog.dismiss();

                        //Display error message whenever an error occurs
                        Toast.makeText(getApplicationContext(),
                                error.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });


        // Access the RequestQueue through your singleton class.
        MySingleton.getInstance(this).addToRequestQueue(jsArrayRequest);
    }

    /**
     * Validates inputs and shows error if any
     * @return
     */
    private boolean validateInputs() {
        if(KEY_EMPTY.equals(username)){
            etUsername.setError("Username cannot be empty");
            etUsername.requestFocus();
            return false;
        }
        return true;
    }

    /**
     * (2) Request Data Callback method of the @+id/requestData button in activity_main.xml
     *
     * //@param view : the view from the activity, in this case the button.
     *
     */
    public void requestDataCallback() {

        try {
            String connectionInstruction = "";
            String connectionStatus = "";
            if (isNetworkReachable()) {
                // Connectivity dataTask = new Connectivity(mainActivityDataTaskNotification);

                //connectionInstruction = dataTask.execute("https://httpbin.org/get?arg1=1&arg2=2").get();
                // connectionStatus = "Connection Status: Online";
            } else {

                connectionInstruction = "Please check your internet connection and try your request again.";
                connectionStatus = "Connection Status: Offline";
                mainActivityDataTaskNotification.notifyMainActivity(connectionStatus, connectionInstruction);
            }

        } catch (Exception e) {
            String connectionInstruction = e.getMessage();
            String connectionStatus = "";
            mainActivityDataTaskNotification.notifyMainActivity(connectionStatus, connectionInstruction);
        }
    }

    /**
     *  (3) Calling into the ConnectivityManagerr : Class that answers queries about the state of network connectivity.
     * It also notifies applications when network connectivity changes.
     * @url  https://developer.android.com/reference/android/net/ConnectivityManager
     *
     */
    private boolean isNetworkReachable() {
        ConnectivityManager manager =
                (ConnectivityManager) getSystemService(this.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            return true;
        }
        return false;
    }

    /**
     * (4) MainActivityDataTaskNotification (Closure) : Interface Method.
     *
     */
    MainActivityDataTaskNotification mainActivityDataTaskNotification = new MainActivityDataTaskNotification() {
        @Override
        public void notifyMainActivity(String connStatus, String connInstruction) {

            Toast.makeText(getApplicationContext(), connInstruction, Toast.LENGTH_SHORT).show();
            Toast.makeText(getApplicationContext(), connStatus, Toast.LENGTH_SHORT).show();

        }
    };


    /**
     * FORCEFULLY ASK FOR AN APP UPDATE FROM PLAY STORE
     */

    String currentVersion, latestVersion;
    Dialog dialog;
    private void getCurrentVersion(){
        PackageManager pm = this.getPackageManager();
        PackageInfo pInfo = null;

        try {
            pInfo =  pm.getPackageInfo(this.getPackageName(),0);

        } catch (PackageManager.NameNotFoundException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        currentVersion = pInfo.versionName;

        new GetLatestVersion().execute();

    }

    /**
     *  Code to Force update
     */
    private class GetLatestVersion extends AsyncTask<String, String, JSONObject> {

            private ProgressDialog progressDialog;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected JSONObject doInBackground(String... params) {
                try {
        //It retrieves the latest version by scraping the content of current version from play store at runtime
                    Document doc = Jsoup.connect("https://play.google.com/store/apps/details?id=com.tscminet.tscminetapp").get();
                    latestVersion = doc.getElementsByClass("htlgb").get(6).text();

                }catch (Exception e){
                    e.printStackTrace();

                }

                return new JSONObject();
            }

            @Override
            protected void onPostExecute(JSONObject jsonObject) {
                if(latestVersion!=null) {
                    if (!currentVersion.equalsIgnoreCase(latestVersion)){
                        if(!isFinishing()){ //This would help to prevent Error : BinderProxy@45d459c0 is not valid; is your activity running? error
                            showUpdateDialog();
                        }
                    }
                }
                else
                    //background.start();
                super.onPostExecute(jsonObject);
            }
        }

    private void showUpdateDialog(){
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("A New Update is Available");
        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse
                        ("market://details?id=com.tscminet.tscminetapp")));
                dialog.dismiss();
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
               // background.start();
            }
        });

        builder.setCancelable(false);
        dialog = builder.show();
    }
}
