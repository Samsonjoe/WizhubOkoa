package com.tscminet.tscminetapp.faqFragmentPages;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.tscminet.tscminetapp.homeFragmentPages.UploadFilesInHomeFragment;
import com.tscminet.tscminetapp.homeFragmentPages.UserProfileInHomeFragment;
import com.tscminet.tscminetapp.homeFragmentPages.ViewUploadedFilesInHomeFragment;

public class TabFaqActivityAdapter extends FragmentStatePagerAdapter {

    String[] tabArray = new String[]{"How to","Download Files"};
    Integer tabNumber = 2;


    public TabFaqActivityAdapter(FragmentManager fm) {
        //super(fm);
        super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
    }



    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return tabArray[position];
    }

    @Override
    public Fragment getItem(int position) {

        switch (position){
            case 0:
                HowToFaqFragment one1 = new HowToFaqFragment();
                return one1;
            case 1:
                DocumentsTscFragment two2 = new DocumentsTscFragment();
                return two2;

        }
        return null;
    }

    @Override
    public int getCount() {
        return tabNumber;
    }

}
