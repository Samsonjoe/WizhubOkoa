package com.tscminet.tscminetapp.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.tscminet.tscminetapp.R;
import com.tscminet.tscminetapp.faqFragmentPages.TabFaqActivityAdapter;
import com.tscminet.tscminetapp.loginPage.SessionHandler;

public class FAQFragment extends androidx.fragment.app.Fragment {

    public FAQFragment(){
        // Required empty public constructor
    }

    private SessionHandler session;
    private TabLayout tabLayout;
    private ViewPager viewPager;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_faq, container, false);
        session = new SessionHandler(getActivity().getApplicationContext());


        tabLayout = view.findViewById(R.id.tabsFaq);
        viewPager = view.findViewById(R.id.view_pager_faq);

        viewPager.setAdapter(new TabFaqActivityAdapter(getChildFragmentManager()));
        tabLayout.setupWithViewPager(viewPager);



        return view;
    }
}
